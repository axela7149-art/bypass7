import Foundation

enum DevicePatchService {
    static func apply(project: PatchProject) throws -> PatchTransactionReceipt {
        let resolvedProject = try resolveGameBundle(in: project)
        for rule in resolvedProject.rules {
            log("patch: applying project=\(resolvedProject.name) bundle=\(rule.bundleID) path=\(rule.relativePath)")
        }
        let bundleIDs = orderedBundleIdentifiers(in: resolvedProject)
        return try withResolvedContainers(bundleIDs: bundleIDs) { roots in
            try PatchTransaction.apply(
                project: resolvedProject,
                backupRoot: try PatchProjectLibrary.backupRootURL(),
                containerResolver: { bundleID in
                    guard let root = roots[bundleID] else {
                        throw PatchPackageError.targetAppUnavailable(bundleID)
                    }
                    return root
                }
            )
        }
    }

    static func restore(receipt: PatchTransactionReceipt) throws {
        let bundleIDs = try PatchTransaction.requiredBundleIdentifiers(for: receipt)
        try withResolvedContainers(bundleIDs: bundleIDs) { roots in
            try PatchTransaction.restore(
                receipt: receipt,
                containerResolver: { bundleID in
                    guard let root = roots[bundleID] else {
                        throw PatchPackageError.targetAppUnavailable(bundleID)
                    }
                    return root
                }
            )
        }
    }

    static func latestReceipt(projectID: UUID) -> PatchTransactionReceipt? {
        guard let backupRoot = try? PatchProjectLibrary.backupRootURL() else { return nil }
        return PatchTransaction.latestReceipt(projectID: projectID, backupRoot: backupRoot)
    }

    private static func orderedBundleIdentifiers(in project: PatchProject) -> [String] {
        project.allBundleIdentifiers
    }

    private static func resolveGameBundle(in project: PatchProject) throws -> PatchProject {
        let gameBundleIDs = Set(project.allBundleIdentifiers.filter {
            $0 == "com.dts.freefireth" || $0 == "com.dts.freefiremax"
        })
        guard gameBundleIDs.count == 1,
              let sourceBundleID = gameBundleIDs.first else {
            return project
        }

        let candidates = sourceBundleID == "com.dts.freefireth"
            ? ["com.dts.freefireth", "com.dts.freefiremax"]
            : ["com.dts.freefiremax", "com.dts.freefireth"]
        guard let installedBundleID = candidates.first(where: {
            ContainerStore.resolveAppContainerPath(bundleID: $0) != nil
        }) else {
            log("patch: no supported Free Fire container found; requested=\(sourceBundleID)")
            return project
        }

        guard installedBundleID != sourceBundleID else {
            log("patch: using requested game bundle \(sourceBundleID)")
            return project
        }

        var resolved = project
        resolved.bundleIdentifiers = resolved.bundleIdentifiers.map {
            $0 == sourceBundleID ? installedBundleID : $0
        }
        resolved.directories = resolved.directories.map { directory in
            var copy = directory
            if copy.bundleID == sourceBundleID { copy.bundleID = installedBundleID }
            return copy
        }
        resolved.rules = resolved.rules.map { rule in
            var copy = rule
            if copy.bundleID == sourceBundleID { copy.bundleID = installedBundleID }
            return copy
        }
        log("patch: remapped game bundle \(sourceBundleID) -> \(installedBundleID)")
        return resolved
    }

    private static func withResolvedContainers<T>(
        bundleIDs: [String],
        operation: ([String: URL]) throws -> T
    ) throws -> T {
        var roots: [String: URL] = [:]

        for bundleID in bundleIDs {
            guard let path = ContainerStore.resolveAppContainerPath(bundleID: bundleID),
                  ContainerStore.isApplicationContainerPath(path) else {
                throw PatchPackageError.targetAppUnavailable(bundleID)
            }
            roots[bundleID] = PatchPathValidator.canonicalFileURL(URL(fileURLWithPath: path, isDirectory: true))
        }
        return try operation(roots)
    }
}
