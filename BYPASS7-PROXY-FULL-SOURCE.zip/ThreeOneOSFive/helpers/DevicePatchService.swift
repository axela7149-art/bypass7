import Foundation

enum DevicePatchService {
    static func apply(project: PatchProject) throws -> PatchTransactionReceipt {
        var resolvedProject = try resolveGameBundle(in: project)
        resolvedProject = resolveExistingMenuTargets(in: resolvedProject)
        for rule in resolvedProject.rules {
            log("patch: applying project=\(resolvedProject.name) bundle=\(rule.bundleID) path=\(rule.relativePath)")
        }
        let bundleIDs = orderedBundleIdentifiers(in: resolvedProject)
        return try withResolvedContainers(bundleIDs: bundleIDs) { roots in
            try PatchTransaction.apply(
                project: resolvedProject,
                backupRoot: try PatchProjectLibrary.backupRootURL(),
                containerResolver: { bundleID in
                    guard let root = roots[bundleID] else {
                        throw PatchPackageError.targetAppUnavailable(bundleID)
                    }
                    return root
                }
            )
        }
    }

    static func restore(receipt: PatchTransactionReceipt) throws {
        let bundleIDs = try PatchTransaction.requiredBundleIdentifiers(for: receipt)
        try withResolvedContainers(bundleIDs: bundleIDs) { roots in
            try PatchTransaction.restore(
                receipt: receipt,
                containerResolver: { bundleID in
                    guard let root = roots[bundleID] else {
                        throw PatchPackageError.targetAppUnavailable(bundleID)
                    }
                    return root
                }
            )
        }
    }

    static func latestReceipt(projectID: UUID) -> PatchTransactionReceipt? {
        guard let backupRoot = try? PatchProjectLibrary.backupRootURL() else { return nil }
        return PatchTransaction.latestReceipt(projectID: projectID, backupRoot: backupRoot)
    }

    private static func orderedBundleIdentifiers(in project: PatchProject) -> [String] {
        project.allBundleIdentifiers
    }

    private static func resolveGameBundle(in project: PatchProject) throws -> PatchProject {
        let gameBundleIDs = Set(project.allBundleIdentifiers.filter {
            $0 == "com.dts.freefireth" || $0 == "com.dts.freefiremax"
        })
        guard gameBundleIDs.count == 1,
              let sourceBundleID = gameBundleIDs.first else {
            return project
        }

        let candidates = sourceBundleID == "com.dts.freefireth"
            ? ["com.dts.freefireth", "com.dts.freefiremax"]
            : ["com.dts.freefiremax", "com.dts.freefireth"]
        guard let installedBundleID = candidates.first(where: {
            ContainerStore.resolveAppContainerPath(bundleID: $0) != nil
        }) else {
            log("patch: no supported Free Fire container found; requested=\(sourceBundleID)")
            return project
        }

        guard installedBundleID != sourceBundleID else {
            log("patch: using requested game bundle \(sourceBundleID)")
            return project
        }

        var resolved = project
        resolved.bundleIdentifiers = resolved.bundleIdentifiers.map {
            $0 == sourceBundleID ? installedBundleID : $0
        }
        resolved.directories = resolved.directories.map { directory in
            var copy = directory
            if copy.bundleID == sourceBundleID { copy.bundleID = installedBundleID }
            return copy
        }
        resolved.rules = resolved.rules.map { rule in
            var copy = rule
            if copy.bundleID == sourceBundleID { copy.bundleID = installedBundleID }
            return copy
        }
        log("patch: remapped game bundle \(sourceBundleID) -> \(installedBundleID)")
        return resolved
    }

    private static func resolveExistingMenuTargets(in project: PatchProject) -> PatchProject {
        guard project.name.localizedCaseInsensitiveContains("MENU TESTE") else {
            return project
        }

        var resolved = project
        let fileManager = FileManager.default
        for index in resolved.rules.indices {
            let rule = resolved.rules[index]
            guard let containerPath = ContainerStore.resolveAppContainerPath(bundleID: rule.bundleID) else {
                continue
            }
            let root = PatchPathValidator.canonicalFileURL(
                URL(fileURLWithPath: containerPath, isDirectory: true)
            )
            let expected = (try? PatchPathValidator.resolveContainedTargetURL(
                relativePath: rule.relativePath,
                containerRoot: root
            ))
            guard let expected, !fileManager.fileExists(atPath: expected.path) else {
                continue
            }

            guard let discovered = discoverExistingFile(
                named: rule.replacementFilename,
                under: root,
                fileManager: fileManager
            ) else {
                log("patch: MENU TESTE target missing; keeping requested path=\(rule.relativePath)")
                continue
            }

            let prefix = root.path.hasSuffix("/") ? root.path : root.path + "/"
            let relativePath = String(discovered.path.dropFirst(prefix.count))
            guard let canonical = try? PatchPathValidator.canonicalRelativePath(relativePath) else {
                continue
            }
            resolved.rules[index].relativePath = canonical
            log("patch: MENU TESTE redirected \(rule.relativePath) -> \(canonical)")
        }
        return resolved
    }

    private static func discoverExistingFile(
        named filename: String,
        under root: URL,
        fileManager: FileManager
    ) -> URL? {
        guard let enumerator = fileManager.enumerator(
            at: root,
            includingPropertiesForKeys: [.isRegularFileKey, .isSymbolicLinkKey],
            options: [.skipsHiddenFiles]
        ) else {
            return nil
        }

        var matches: [URL] = []
        for case let url as URL in enumerator {
            guard url.lastPathComponent == filename,
                  let values = try? url.resourceValues(forKeys: [.isRegularFileKey, .isSymbolicLinkKey]),
                  values.isRegularFile == true,
                  values.isSymbolicLink != true else {
                continue
            }
            matches.append(url)
            if matches.count >= 32 { break }
        }
        return matches.sorted { lhs, rhs in
            let lhsDocuments = lhs.path.contains("/Documents/")
            let rhsDocuments = rhs.path.contains("/Documents/")
            if lhsDocuments != rhsDocuments { return lhsDocuments }
            return lhs.path.count < rhs.path.count
        }.first
    }

    private static func withResolvedContainers<T>(
        bundleIDs: [String],
        operation: ([String: URL]) throws -> T
    ) throws -> T {
        var roots: [String: URL] = [:]

        for bundleID in bundleIDs {
            guard let path = ContainerStore.resolveAppContainerPath(bundleID: bundleID),
                  ContainerStore.isApplicationContainerPath(path) else {
                throw PatchPackageError.targetAppUnavailable(bundleID)
            }
            roots[bundleID] = PatchPathValidator.canonicalFileURL(URL(fileURLWithPath: path, isDirectory: true))
        }
        return try operation(roots)
    }
}
