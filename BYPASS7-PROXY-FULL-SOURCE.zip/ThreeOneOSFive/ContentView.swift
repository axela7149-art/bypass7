import SwiftUI
import UIKit

struct ContentView: View {
    @EnvironmentObject private var patchDraftCoordinator: PatchDraftCoordinator
    @EnvironmentObject private var patchStore: PatchProjectStore
    @AppStorage("bypass7.darkTheme") private var isDarkMode = true

    @State private var selectedTab: BYPASS7Tab = .aims
    @State private var selectedGame: BYPASS7Game = .normal
    @State private var showSettings = false
    @State private var showLogs = false
    @State private var showPatchLibrary = false

    @State private var pendingApply: BYPASS7PatchRequest?
    @State private var pendingRestore: BYPASS7PatchRequest?
    @State private var pendingChangedRestore: BYPASS7PatchRequest?
    @State private var showApplyConfirmation = false
    @State private var showRestoreConfirmation = false
    @State private var showChangedRestoreConfirmation = false
    @State private var changedRestorePaths: [String] = []
    @State private var workingPatchID: UUID?
    @State private var workingOperation: BYPASS7PatchOperation?
    @State private var actionAlert: BYPASS7Alert?

    var body: some View {
        VStack(spacing: 0) {
            header
            Rectangle()
                .fill(AppTheme.accent.opacity(0.08))
                .frame(height: 0.5)

            Group {
                if selectedTab == .aims {
                    aimsScreen
                } else {
                    homeScreen
                }
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)

            bottomNavigation
        }
        .background(AppTheme.pageBackground.ignoresSafeArea())
        .preferredColorScheme(isDarkMode ? .dark : .light)
        .tint(AppTheme.accent)
        .sheet(isPresented: $showSettings) {
            SettingsView()
        }
        .sheet(isPresented: $showLogs) {
            LogView()
        }
        .sheet(isPresented: $showPatchLibrary) {
            PatchProjectsView(
                onOpenSettings: { showSettings = true },
                onOpenLogs: { showLogs = true }
            )
        }
        .confirmationDialog(
            Text("Ativar \(pendingApply?.definition.displayName ?? "patch")?"),
            isPresented: $showApplyConfirmation,
            titleVisibility: .visible
        ) {
            Button("Ativar") {
                if let pendingApply { apply(pendingApply) }
                pendingApply = nil
            }
            Button("Cancelar", role: .cancel) { pendingApply = nil }
        } message: {
            Text("O app validará o destino e salvará uma cópia dos arquivos originais antes de aplicar o patch no Free Fire Normal.")
        }
        .confirmationDialog(
            Text("Restaurar os arquivos originais?"),
            isPresented: $showRestoreConfirmation,
            titleVisibility: .visible
        ) {
            Button("Restaurar", role: .destructive) {
                if let pendingRestore { prepareRestore(pendingRestore) }
                pendingRestore = nil
            }
            Button("Cancelar", role: .cancel) { pendingRestore = nil }
        } message: {
            Text("Feche o Free Fire antes. Os arquivos voltarão ao estado salvo antes da aplicação do patch.")
        }
        .confirmationDialog(
            Text("Alguns arquivos foram alterados"),
            isPresented: $showChangedRestoreConfirmation,
            titleVisibility: .visible
        ) {
            Button("Restaurar mesmo assim", role: .destructive) {
                if let pendingChangedRestore {
                    restore(pendingChangedRestore, allowChangedTargets: true)
                }
                pendingChangedRestore = nil
            }
            Button("Cancelar", role: .cancel) { pendingChangedRestore = nil }
        } message: {
            Text(changedRestoreMessage)
        }
        .alert(item: $actionAlert) { alert in
            Alert(
                title: Text(alert.title),
                message: Text(alert.message),
                dismissButton: .default(Text("OK"))
            )
        }
        .onChange(of: patchDraftCoordinator.request?.id) { requestID in
            if requestID != nil { showPatchLibrary = true }
        }
        .onChange(of: patchDraftCoordinator.importRequest?.id) { requestID in
            if requestID != nil { showPatchLibrary = true }
        }
    }

    private var header: some View {
        HStack(spacing: 12) {
            Button {
                showSettings = true
            } label: {
                ZStack {
                    Circle()
                        .fill(AppTheme.accent)
                        .frame(width: 50, height: 50)
                    Image(systemName: "person.fill")
                        .font(.system(size: 20, weight: .semibold))
                        .foregroundStyle(AppTheme.onAccent)
                }
            }
            .buttonStyle(.plain)
            .accessibilityLabel("Perfil e configurações")

            VStack(alignment: .leading, spacing: 3) {
                Text(selectedTab.title)
                    .font(.system(size: 20, weight: .semibold))
                    .foregroundStyle(.primary)
                Text("macielfilza")
                    .font(.system(size: 11, weight: .bold))
                    .tracking(2.4)
                    .foregroundStyle(AppTheme.accent)
            }

            Spacer(minLength: 12)

            Button {
                isDarkMode.toggle()
            } label: {
                ZStack {
                    Circle()
                        .fill(AppTheme.accent.opacity(0.07))
                        .frame(width: 44, height: 44)
                    Image(systemName: isDarkMode ? "sun.max.fill" : "moon.fill")
                        .font(.system(size: 17, weight: .semibold))
                        .foregroundStyle(AppTheme.accent)
                }
            }
            .buttonStyle(.plain)
            .accessibilityLabel("Alternar tema")
        }
        .padding(.horizontal, 20)
        .padding(.vertical, 12)
        .background(AppTheme.consoleBackground.ignoresSafeArea(edges: .top))
    }

    private var aimsScreen: some View {
        ScrollView(showsIndicators: false) {
            VStack(alignment: .leading, spacing: 0) {
                Text("INJETAR")
                    .font(.system(size: 20, weight: .semibold))
                    .foregroundStyle(.primary)
                    .frame(maxWidth: .infinity)
                    .padding(.top, 24)
                    .padding(.bottom, 52)

                Text("RECURSOS")
                    .font(.system(size: 12, weight: .bold))
                    .tracking(2.8)
                    .foregroundStyle(AppTheme.accent)

                CreatorBannerText()
                    .padding(.top, 6)
                    .padding(.bottom, 20)

                gameSelector

                Text("PATCHES DISPONÍVEIS")
                    .font(.system(size: 12, weight: .bold))
                    .tracking(1.7)
                    .foregroundStyle(Color(uiColor: .secondaryLabel))
                    .padding(.top, 20)
                    .padding(.bottom, 10)

                patchCard

                if selectedGame == .max {
                    HStack(alignment: .top, spacing: 8) {
                        Image(systemName: "info.circle.fill")
                            .foregroundStyle(AppTheme.accent)
                        Text("Os seis patches incluídos são somente para Free Fire Normal. Patches para Free Fire Max não estão neste pacote.")
                            .foregroundStyle(Color(uiColor: .secondaryLabel))
                    }
                    .font(.system(size: 12))
                    .padding(.top, 12)
                }

                if hasUnmappedLegacyPatch {
                    HStack(alignment: .top, spacing: 8) {
                        Image(systemName: "exclamationmark.triangle.fill")
                            .foregroundStyle(AppTheme.accent)
                        VStack(alignment: .leading, spacing: 6) {
                            Text("Há um patch HS de uma versão anterior ativo.")
                                .foregroundStyle(.primary)
                            Button("Gerenciar e restaurar") { showPatchLibrary = true }
                                .font(.system(size: 12, weight: .semibold))
                                .foregroundStyle(AppTheme.accent)
                        }
                    }
                    .font(.system(size: 12))
                    .padding(.top, 12)
                }

            }
            .padding(.horizontal, 18)
            .padding(.bottom, 22)
        }
        .background(AppTheme.pageBackground)
    }

    private var gameSelector: some View {
        HStack(spacing: 3) {
            gameButton(.normal)
            gameButton(.max)
        }
        .padding(3)
        .background(AppTheme.accent.opacity(0.08), in: Capsule())
    }

    private func gameButton(_ game: BYPASS7Game) -> some View {
        Button {
            withAnimation(.easeInOut(duration: 0.18)) {
                selectedGame = game
            }
        } label: {
            Text(game.title)
                .font(.system(size: 13, weight: .semibold))
                .foregroundStyle(selectedGame == game ? AppTheme.accent : Color(uiColor: .secondaryLabel))
                .lineLimit(1)
                .minimumScaleFactor(0.85)
                .frame(maxWidth: .infinity)
                .padding(.vertical, 10)
                .background {
                    if selectedGame == game {
                        Capsule().fill(AppTheme.accent.opacity(0.18))
                    }
                }
        }
        .buttonStyle(.plain)
        .accessibilityAddTraits(selectedGame == game ? .isSelected : [])
    }

    private var patchCard: some View {
        VStack(spacing: 0) {
            if patchStore.isBusy {
                HStack(spacing: 10) {
                    ProgressView().tint(AppTheme.accent)
                    Text("Carregando patches...")
                        .font(.system(size: 13, weight: .medium))
                        .foregroundStyle(Color(uiColor: .secondaryLabel))
                    Spacer()
                }
                .padding(18)
            } else {
                ForEach(BYPASS7PatchCatalog.definitions) { definition in
                    let item = patchItem(for: definition)
                    let active = item.map(isPatchActive) ?? false
                    let isPendingActivation = item.map { pendingApply?.item.id == $0.id } ?? false
                    let blockedByHS = isBlockedByAnotherHighSensitivity(definition, active: active)
                    let rowStatus = isPendingActivation
                        ? (text: "Confirme para ativar", icon: "checkmark.circle")
                        : (blockedByHS
                            ? (text: "Outro HS está ativo", icon: "lock.fill")
                            : status(for: definition, item: item, active: active))
                    PatchActivationRow(
                        definition: definition,
                        isOn: active || isPendingActivation,
                        status: rowStatus.text,
                        statusIcon: rowStatus.icon,
                        isActive: active,
                        isWorking: item.map { workingPatchID == $0.id } ?? false,
                        isEnabled: item?.project != nil
                            && workingPatchID == nil
                            && pendingApply == nil
                            && !blockedByHS
                            && (selectedGame == .normal || active),
                        onToggle: { enabled in requestPatchChange(enabled, definition: definition) }
                    )
                    if definition.id != BYPASS7PatchCatalog.definitions.last?.id {
                        Rectangle()
                            .fill(AppTheme.accent.opacity(0.07))
                            .frame(height: 0.5)
                            .padding(.leading, 50)
                    }
                }
            }
        }
        .padding(7)
        .background(AppTheme.patchCardBackground, in: RoundedRectangle(cornerRadius: 17, style: .continuous))
        .overlay {
            RoundedRectangle(cornerRadius: 17, style: .continuous)
                .strokeBorder(AppTheme.cardOutline, lineWidth: 1)
        }
    }

    private var homeScreen: some View {
        ScrollView(showsIndicators: false) {
            VStack(spacing: 18) {
                Text("macielfilza")
                    .font(.system(size: 23, weight: .bold, design: .rounded))
                    .foregroundStyle(.primary)
                    .padding(.top, 34)

                Text("Sua central de patches")
                    .font(.system(size: 15))
                    .foregroundStyle(Color(uiColor: .secondaryLabel))

                HStack(spacing: 12) {
                    homeInfoCard(value: "\(BYPASS7PatchCatalog.definitions.count)", title: "PATCHES", icon: "scope")
                    homeInfoCard(value: "NORMAL", title: "FREE FIRE", icon: "gamecontroller.fill")
                }
                .padding(.top, 4)

                Button {
                    selectedTab = .aims
                } label: {
                    Label("Abrir patches", systemImage: "scope")
                        .font(.system(size: 15, weight: .semibold))
                        .foregroundStyle(AppTheme.onAccent)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 14)
                        .background(AppTheme.accent, in: RoundedRectangle(cornerRadius: 12, style: .continuous))
                }
                .buttonStyle(.plain)
                .padding(.top, 6)

            }
            .padding(.horizontal, 24)
            .padding(.bottom, 28)
            .frame(maxWidth: 520)
            .frame(maxWidth: .infinity)
        }
        .background(AppTheme.pageBackground)
    }

    private func homeInfoCard(value: String, title: String, icon: String) -> some View {
        VStack(alignment: .leading, spacing: 12) {
            Image(systemName: icon)
                .font(.system(size: 16, weight: .semibold))
                .foregroundStyle(AppTheme.accent)
            Text(value)
                .font(.system(size: 18, weight: .bold))
                .foregroundStyle(.primary)
                .lineLimit(1)
                .minimumScaleFactor(0.8)
            Text(title)
                .font(.system(size: 10, weight: .bold))
                .tracking(1.4)
                .foregroundStyle(Color(uiColor: .secondaryLabel))
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(14)
        .background(AppTheme.patchCardBackground, in: RoundedRectangle(cornerRadius: 14, style: .continuous))
        .overlay {
            RoundedRectangle(cornerRadius: 14, style: .continuous)
                .strokeBorder(AppTheme.cardOutline, lineWidth: 1)
        }
    }

    private var bottomNavigation: some View {
        HStack(spacing: 10) {
            ForEach(BYPASS7Tab.allCases) { tab in
                Button {
                    withAnimation(.easeInOut(duration: 0.18)) { selectedTab = tab }
                } label: {
                    VStack(spacing: 4) {
                        Image(systemName: tab.systemImage)
                            .font(.system(size: 17, weight: .semibold))
                        Text(tab.title)
                            .font(.system(size: 12, weight: .semibold))
                    }
                    .foregroundStyle(selectedTab == tab ? AppTheme.accent : Color(uiColor: .secondaryLabel))
                    .frame(maxWidth: .infinity)
                    .frame(height: 48)
                    .background {
                        if selectedTab == tab {
                            RoundedRectangle(cornerRadius: 15, style: .continuous)
                                .fill(AppTheme.accent.opacity(0.17))
                        }
                    }
                }
                .buttonStyle(.plain)
                .accessibilityAddTraits(selectedTab == tab ? .isSelected : [])
            }
        }
        .padding(.horizontal, 10)
        .padding(.top, 7)
        .padding(.bottom, 5)
        .background(AppTheme.consoleBackground.ignoresSafeArea(edges: .bottom))
        .overlay(alignment: .top) {
            Rectangle()
                .fill(Color.white.opacity(0.08))
                .frame(height: 0.5)
        }
    }

    private func patchItem(for definition: BYPASS7PatchDefinition) -> PatchLibraryItem? {
        let expectedNames = Set(definition.matchNames.map(normalizedName))
        let matches = patchStore.items.filter { item in
            let projectName = item.project?.name
            let fileName = item.packageURL.deletingPathExtension().lastPathComponent
            return [projectName, Optional(fileName)]
                .compactMap { $0 }
                .map(normalizedName)
                .contains(where: expectedNames.contains)
        }

        if let active = matches.first(where: isPatchActive) { return active }
        if definition.isHighSensitivity,
           let legacyActive = matches.first(where: {
               $0.id == BYPASS7PatchCatalog.legacySharedHighSensitivityID
                   && isPatchActive($0)
           }) {
            return legacyActive
        }
        return matches.first(where: { $0.id != BYPASS7PatchCatalog.legacySharedHighSensitivityID })
            ?? matches.first
    }

    private func normalizedName(_ value: String) -> String {
        value.folding(options: [.diacriticInsensitive, .caseInsensitive], locale: Locale(identifier: "pt_BR"))
            .replacingOccurrences(of: " ", with: "")
            .replacingOccurrences(of: "_", with: "")
    }

    private func isPatchActive(_ item: PatchLibraryItem) -> Bool {
        DevicePatchService.latestReceipt(projectID: item.id) != nil
    }

    private var activeHighSensitivityPatchID: UUID? {
        BYPASS7PatchCatalog.definitions
            .filter(\.isHighSensitivity)
            .compactMap { patchItem(for: $0) }
            .first(where: isPatchActive)?.id
    }

    private func isBlockedByAnotherHighSensitivity(
        _ definition: BYPASS7PatchDefinition,
        active: Bool
    ) -> Bool {
        guard definition.isHighSensitivity, !active else { return false }
        return activeHighSensitivityPatchID != nil || hasUnmappedLegacyPatch
    }

    private func status(
        for definition: BYPASS7PatchDefinition,
        item: PatchLibraryItem?,
        active: Bool
    ) -> (text: String, icon: String) {
        if item.map({ workingPatchID == $0.id }) == true {
            return workingOperation == .restoring
                ? ("Restaurando...", "arrow.uturn.backward.circle")
                : ("Ativando...", "arrow.triangle.2.circlepath")
        }
        if active { return ("Ativado", "checkmark.circle.fill") }
        if let item, item.project == nil { return ("Pacote bloqueado", "lock.fill") }
        if selectedGame == .max { return ("Somente Free Fire Normal", "info.circle") }
        if item == nil {
            return (patchStore.isBusy ? "Carregando..." : "Pacote indisponível", "exclamationmark.circle")
        }
        return (definition.offStatus, definition.offStatusIcon)
    }

    private func requestPatchChange(_ shouldActivate: Bool, definition: BYPASS7PatchDefinition) {
        guard let item = patchItem(for: definition) else {
            actionAlert = BYPASS7Alert(
                title: "Patch indisponível",
                message: "Não encontrei o pacote \(definition.displayName) nesta build. Abra a biblioteca e atualize os patches."
            )
            return
        }
        let request = BYPASS7PatchRequest(item: item, definition: definition)
        if shouldActivate {
            guard selectedGame == .normal else { return }
            pendingApply = request
            showApplyConfirmation = true
        } else {
            pendingRestore = request
            showRestoreConfirmation = true
        }
    }

    private func apply(_ request: BYPASS7PatchRequest) {
        guard let baseProject = request.item.project else {
            actionAlert = BYPASS7Alert(title: "Patch indisponível", message: "Este pacote precisa ser desbloqueado antes de ser ativado.")
            return
        }
        workingPatchID = request.item.id
        workingOperation = .applying
        let item = request.item
        let store = patchStore

        Task.detached(priority: .userInitiated) {
            do {
                let shouldSynchronizeWorkspace = request.definition.synchronizesWorkspaceBeforeApply
                    && item.summary.schemaVersion >= 2
                    && item.canInspectContents
                let project = shouldSynchronizeWorkspace
                    ? try PatchProjectLibrary.synchronizeWorkspace(item: item)
                    : baseProject
                _ = try DevicePatchService.apply(project: project)
                await MainActor.run {
                    store.reload()
                    workingPatchID = nil
                    workingOperation = nil
                    actionAlert = BYPASS7Alert(title: "Patch ativado", message: "\(request.definition.displayName) foi aplicado. O switch ficará ativo enquanto este patch estiver instalado.")
                }
            } catch let error as PatchPackageError {
                log("patch: activation failed for \(request.definition.displayName) [\(request.item.id.uuidString)]: \(error.errorDescription ?? String(describing: error))")
                await MainActor.run {
                    workingPatchID = nil
                    workingOperation = nil
                    actionAlert = alert(for: error, restoring: false)
                }
            } catch {
                log("patch: unexpected activation failure for \(request.definition.displayName) [\(request.item.id.uuidString)]: \(error.localizedDescription)")
                await MainActor.run {
                    workingPatchID = nil
                    workingOperation = nil
                    let details = error.localizedDescription
                    actionAlert = BYPASS7Alert(
                        title: "Falha ao ativar",
                        message: details.isEmpty
                            ? "Não foi possível aplicar o patch. Feche o Free Fire e tente novamente."
                            : "Não foi possível aplicar o patch. \(details)"
                    )
                }
            }
        }
    }

    private func prepareRestore(_ request: BYPASS7PatchRequest) {
        guard let receipt = DevicePatchService.latestReceipt(projectID: request.item.id) else {
            patchStore.reload()
            actionAlert = BYPASS7Alert(title: "Patch já desativado", message: "Não há uma aplicação ativa deste patch para restaurar.")
            return
        }
        workingPatchID = request.item.id
        workingOperation = .restoring

        Task.detached(priority: .userInitiated) {
            do {
                let inspection = try DevicePatchService.inspectRestore(receipt: receipt)
                if inspection.changedTargets.isEmpty {
                    try DevicePatchService.restore(receipt: receipt)
                    await MainActor.run {
                        patchStore.reload()
                        workingPatchID = nil
                        workingOperation = nil
                        actionAlert = BYPASS7Alert(title: "Patch desativado", message: "Os arquivos originais foram restaurados.")
                    }
                } else {
                    await MainActor.run {
                        workingPatchID = nil
                        workingOperation = nil
                        changedRestorePaths = inspection.changedTargets.map(\.displayPath)
                        pendingChangedRestore = request
                        showChangedRestoreConfirmation = true
                    }
                }
            } catch let error as PatchPackageError {
                await MainActor.run {
                    workingPatchID = nil
                    workingOperation = nil
                    actionAlert = alert(for: error, restoring: true)
                }
            } catch {
                await MainActor.run {
                    workingPatchID = nil
                    workingOperation = nil
                    actionAlert = BYPASS7Alert(title: "Falha ao verificar restauração", message: "Não foi possível verificar os arquivos do patch.")
                }
            }
        }
    }

    private func restore(_ request: BYPASS7PatchRequest, allowChangedTargets: Bool) {
        guard let receipt = DevicePatchService.latestReceipt(projectID: request.item.id) else {
            patchStore.reload()
            return
        }
        workingPatchID = request.item.id
        workingOperation = .restoring

        Task.detached(priority: .userInitiated) {
            do {
                try DevicePatchService.restore(
                    receipt: receipt,
                    allowChangedTargets: allowChangedTargets
                )
                await MainActor.run {
                    patchStore.reload()
                    workingPatchID = nil
                    workingOperation = nil
                    actionAlert = BYPASS7Alert(title: "Patch desativado", message: "Os arquivos originais foram restaurados.")
                }
            } catch let error as PatchPackageError {
                await MainActor.run {
                    workingPatchID = nil
                    workingOperation = nil
                    actionAlert = alert(for: error, restoring: true)
                }
            } catch {
                await MainActor.run {
                    workingPatchID = nil
                    workingOperation = nil
                    actionAlert = BYPASS7Alert(title: "Falha ao restaurar", message: "Não foi possível restaurar os arquivos originais.")
                }
            }
        }
    }

    private func alert(for error: PatchPackageError, restoring: Bool) -> BYPASS7Alert {
        if case let .targetOccupied(path) = error {
            return BYPASS7Alert(
                title: "Outro patch está ativo",
                message: "Esse destino já está sendo usado por outro patch. Desative o patch atual antes de ativar outro.\n\n\(path)"
            )
        }
        if case let .targetAppUnavailable(bundleID) = error {
            let target = bundleID == "com.dts.freefireth" ? "Free Fire Normal" : bundleID
            return BYPASS7Alert(
                title: "Jogo não encontrado",
                message: "Não foi possível localizar o app \(target) no dispositivo."
            )
        }
        let fallback = restoring
            ? "Não foi possível restaurar os arquivos originais."
            : "Não foi possível aplicar o patch."
        return BYPASS7Alert(
            title: restoring ? "Falha ao restaurar" : "Falha ao ativar",
            message: error.errorDescription ?? fallback
        )
    }

    private var changedRestoreMessage: String {
        var visiblePaths = changedRestorePaths.prefix(5).joined(separator: "\n")
        if changedRestorePaths.count > 5 { visiblePaths += "\n…" }
        return "Alguns arquivos mudaram depois da aplicação:\n\(visiblePaths)\n\nO app fará um backup do estado atual antes de restaurar."
    }

    private var hasUnmappedLegacyPatch: Bool {
        guard DevicePatchService.latestReceipt(
            projectID: BYPASS7PatchCatalog.legacySharedHighSensitivityID
        ) != nil else { return false }
        return !BYPASS7PatchCatalog.definitions
            .filter(\.isHighSensitivity)
            .contains { patchItem(for: $0)?.id == BYPASS7PatchCatalog.legacySharedHighSensitivityID }
    }
}

private struct CreatorBannerText: View {
    @Environment(\.colorScheme) private var colorScheme
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @State private var gradientOffset: CGFloat = -1.0

    private var titleGradient: LinearGradient {
        let colors: [Color] = colorScheme == .dark
            ? [
                .red,
                .green,
                .yellow,
                .red,
                .green,
                .yellow,
                .red
            ]
            : [
                Color(red: 0.78, green: 0.08, blue: 0.10),
                Color(red: 0.08, green: 0.42, blue: 0.19),
                Color(red: 0.55, green: 0.44, blue: 0.0),
                Color(red: 0.78, green: 0.08, blue: 0.10),
                Color(red: 0.08, green: 0.42, blue: 0.19),
                Color(red: 0.55, green: 0.44, blue: 0.0),
                Color(red: 0.78, green: 0.08, blue: 0.10)
            ]

        return LinearGradient(
            colors: colors,
            startPoint: UnitPoint(x: gradientOffset, y: 0.5),
            endPoint: UnitPoint(x: gradientOffset + 1.0, y: 0.5)
        )
    }

    var body: some View {
        Text("CRIADOR MACIEL FILZA")
            .font(.system(size: 22, weight: .semibold))
            .foregroundStyle(titleGradient)
            .animation(
                reduceMotion ? nil : .linear(duration: 3.0).repeatForever(autoreverses: false),
                value: gradientOffset
            )
            .onAppear {
                guard !reduceMotion else { return }
                gradientOffset = 1.0
            }
            .onChange(of: reduceMotion) { shouldReduceMotion in
                gradientOffset = shouldReduceMotion ? -1.0 : 1.0
            }
    }
}

private struct PatchActivationRow: View {
    let definition: BYPASS7PatchDefinition
    let isOn: Bool
    let status: String
    let statusIcon: String
    let isActive: Bool
    let isWorking: Bool
    let isEnabled: Bool
    let onToggle: (Bool) -> Void

    @Environment(\.colorScheme) private var colorScheme
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @State private var gradientOffset: CGFloat = -1.0

    private var titleGradient: LinearGradient {
        let colors: [Color] = colorScheme == .dark
            ? [
                .red,
                .green,
                .orange,
                .red,
                .green,
                .orange,
                .red
            ]
            : [
                Color(red: 0.78, green: 0.08, blue: 0.10),
                Color(red: 0.08, green: 0.42, blue: 0.19),
                Color(red: 0.70, green: 0.25, blue: 0.0),
                Color(red: 0.78, green: 0.08, blue: 0.10),
                Color(red: 0.08, green: 0.42, blue: 0.19),
                Color(red: 0.70, green: 0.25, blue: 0.0),
                Color(red: 0.78, green: 0.08, blue: 0.10)
            ]

        return LinearGradient(
            colors: colors,
            startPoint: UnitPoint(x: gradientOffset, y: 0.5),
            endPoint: UnitPoint(x: gradientOffset + 1.0, y: 0.5)
        )
    }

    var body: some View {
        HStack(spacing: 11) {
            ZStack {
                RoundedRectangle(cornerRadius: 8, style: .continuous)
                    .fill(AppTheme.accent.opacity(0.13))
                Image(systemName: definition.systemImage)
                    .font(.system(size: 17, weight: .semibold))
                    .foregroundStyle(AppTheme.accent)
            }
            .frame(width: 36, height: 36)
            .accessibilityHidden(true)

            VStack(alignment: .leading, spacing: 4) {
                HStack(spacing: 6) {
                    Text(definition.displayName)
                        .font(.system(size: 14, weight: .semibold))
                        .foregroundStyle(titleGradient)
                        .animation(
                            reduceMotion ? nil : .linear(duration: 3.0).repeatForever(autoreverses: false),
                            value: gradientOffset
                        )
                        .onAppear {
                            guard !reduceMotion else { return }
                            gradientOffset = 1.0
                        }
                        .onChange(of: reduceMotion) { shouldReduceMotion in
                            gradientOffset = shouldReduceMotion ? -1.0 : 1.0
                        }
                        .lineLimit(1)
                        .truncationMode(.tail)
                        .layoutPriority(1)
                    Text("NORMAL")
                        .font(.system(size: 9, weight: .bold))
                        .tracking(0.7)
                        .foregroundStyle(Color(uiColor: .secondaryLabel))
                        .padding(.horizontal, 6)
                        .padding(.vertical, 3)
                        .background(AppTheme.accent.opacity(0.07), in: Capsule())
                }

                HStack(spacing: 5) {
                    Image(systemName: statusIcon)
                        .font(.system(size: 10, weight: .medium))
                    Text(status)
                        .font(.system(size: 11, weight: .regular))
                        .lineLimit(1)
                        .truncationMode(.tail)
                }
                .foregroundStyle(isActive ? AppTheme.accent : Color(uiColor: .secondaryLabel))
            }

            Spacer(minLength: 3)

            if isWorking {
                ProgressView()
                    .tint(AppTheme.accent)
                    .frame(width: 48)
            } else {
                Toggle(
                    definition.displayName,
                    isOn: Binding(
                        get: { isOn },
                        set: { onToggle($0) }
                    )
                )
                .labelsHidden()
                .toggleStyle(SwitchToggleStyle(tint: AppTheme.accent))
                .frame(width: 48)
                .disabled(!isEnabled)
                .accessibilityLabel(definition.displayName)
                .accessibilityValue(status)
            }
        }
        .padding(.horizontal, 8)
        .padding(.vertical, 7)
        .contentShape(Rectangle())
    }
}

private enum BYPASS7Tab: Int, CaseIterable, Identifiable {
    case aims
    case home

    var id: Int { rawValue }
    var title: String { self == .aims ? "Aims" : "Home" }
    var systemImage: String { self == .aims ? "scope" : "house.fill" }
}

private enum BYPASS7Game: Int {
    case normal
    case max

    var title: String {
        self == .normal ? "FREE FIRE NORMAL" : "FREE FIRE MAX"
    }
}

private enum BYPASS7PatchOperation: Equatable {
    case applying
    case restoring
}

private struct BYPASS7PatchDefinition: Identifiable {
    let id: String
    let displayName: String
    let matchNames: [String]
    let systemImage: String
    let offStatus: String
    let offStatusIcon: String
    let isHighSensitivity: Bool
    let synchronizesWorkspaceBeforeApply: Bool

    init(
        id: String,
        displayName: String,
        matchNames: [String],
        systemImage: String,
        offStatus: String,
        offStatusIcon: String,
        isHighSensitivity: Bool,
        synchronizesWorkspaceBeforeApply: Bool = true
    ) {
        self.id = id
        self.displayName = displayName
        self.matchNames = matchNames
        self.systemImage = systemImage
        self.offStatus = offStatus
        self.offStatusIcon = offStatusIcon
        self.isHighSensitivity = isHighSensitivity
        self.synchronizesWorkspaceBeforeApply = synchronizesWorkspaceBeforeApply
    }
}

private enum BYPASS7PatchCatalog {
    static let legacySharedHighSensitivityID = UUID(
        uuidString: "C11E1C4D-CAC4-4FC7-ACF2-4E6BECA09CEB"
    )!

    static let definitions: [BYPASS7PatchDefinition] = [
        BYPASS7PatchDefinition(
            id: "hs-girafa",
            displayName: "HS GIRAFA",
            matchNames: ["HS GIRAFA", "HS GIRAFA.3105"],
            systemImage: "scope",
            offStatus: "Estado não verificado",
            offStatusIcon: "questionmark.circle",
            isHighSensitivity: true
        ),
        BYPASS7PatchDefinition(
            id: "hs-cearense",
            displayName: "HS CEARENSE",
            matchNames: ["HS CEARENSE FF NORMAL", "HS CEARENSE"],
            systemImage: "scope",
            offStatus: "Estado não verificado",
            offStatusIcon: "questionmark.circle",
            isHighSensitivity: true
        ),
        BYPASS7PatchDefinition(
            id: "hs-pescoco",
            displayName: "HS PESCOÇO + ANTENA",
            matchNames: ["HS PESCOÇO + ALTO FF NORMAL", "HS PESCOÇO + ANTENA"],
            systemImage: "scope",
            offStatus: "Estado não verificado",
            offStatusIcon: "questionmark.circle",
            isHighSensitivity: true
        ),
        BYPASS7PatchDefinition(
            id: "hs-peito",
            displayName: "HS PEITO + ANTENA",
            matchNames: ["HS PEITO 80% + ANTENA FF NORMAL", "HS PEITO + ANTENA"],
            systemImage: "scope",
            offStatus: "Estado não verificado",
            offStatusIcon: "questionmark.circle",
            isHighSensitivity: true
        ),
        BYPASS7PatchDefinition(
            id: "144-fps-ffth",
            displayName: "144 FPS FFTH",
            matchNames: ["144 FPS FFTH"],
            systemImage: "scope",
            offStatus: "Estado não verificado",
            offStatusIcon: "questionmark.circle",
            isHighSensitivity: false
        ),
        BYPASS7PatchDefinition(
            id: "aimbot-esp-safe",
            displayName: "AIMBOT + ESP(SAFE)",
            matchNames: ["AIMBOT + ESP(SAFE)"],
            systemImage: "scope",
            offStatus: "Desativado",
            offStatusIcon: "xmark.circle",
            isHighSensitivity: true,
            synchronizesWorkspaceBeforeApply: false
        )
    ]
}

private struct BYPASS7PatchRequest {
    let item: PatchLibraryItem
    let definition: BYPASS7PatchDefinition
}

private struct BYPASS7Alert: Identifiable {
    let id = UUID()
    let title: String
    let message: String
}
