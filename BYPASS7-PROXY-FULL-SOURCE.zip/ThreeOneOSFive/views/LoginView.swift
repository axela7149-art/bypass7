import SwiftUI
import UIKit

struct LoginView: View {
    @ObservedObject var viewModel: AuthenticationViewModel
    @FocusState private var isKeyFieldFocused: Bool
    @State private var contentVisible = false

    private let accent = AppTheme.accent

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            VStack(spacing: 0) {
                LinearGradient(
                    colors: [
                        accent.opacity(0.22),
                        Color.black.opacity(0)
                    ],
                    startPoint: .top,
                    endPoint: .bottom
                )
                .frame(height: 180)
                Spacer()
            }
            .ignoresSafeArea()

            ScrollView(.vertical, showsIndicators: false) {
                VStack(spacing: 18) {
                    Spacer(minLength: 28)

                    Text("macielfilza")
                        .font(.system(size: 26, weight: .bold, design: .rounded))
                        .foregroundStyle(.white)

                    VStack(alignment: .leading, spacing: 8) {
                        Text("Key")
                            .font(.footnote.weight(.semibold))
                            .foregroundStyle(accent)
                        SecureField("Digite sua key", text: $viewModel.enteredKey)
                            .textInputAutocapitalization(.never)
                            .autocorrectionDisabled()
                            .focused($isKeyFieldFocused)
                            .padding(.horizontal, 16)
                            .padding(.vertical, 12)
                            .background(
                                RoundedRectangle(cornerRadius: 12)
                                    .fill(AppTheme.consoleBackground)
                            )
                            .overlay(
                                RoundedRectangle(cornerRadius: 12)
                                    .stroke(isKeyFieldFocused ? accent.opacity(0.9) : accent.opacity(0.30), lineWidth: 1)
                            )
                            .foregroundStyle(.white)
                            .tint(accent)
                            .onSubmit { submit() }
                    }
                    .padding(.horizontal, 8)

                    Button(action: submit) {
                        Group {
                            if viewModel.isLoading {
                                HStack(spacing: 10) {
                                    ProgressView()
                                        .tint(AppTheme.onAccent)
                                    Text("Validando...")
                                }
                            } else if viewModel.isRevalidating {
                                HStack(spacing: 10) {
                                    ProgressView()
                                        .tint(AppTheme.onAccent)
                                    Text("Revalidando...")
                                }
                            } else {
                                Text("Entrar")
                            }
                        }
                        .font(.headline)
                        .foregroundStyle(AppTheme.onAccent)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 14)
                        .background(accent, in: RoundedRectangle(cornerRadius: 12, style: .continuous))
                    }
                    .disabled(viewModel.isLoading || viewModel.isRevalidating)
                    .buttonStyle(.plain)
                    .padding(.horizontal, 8)

                    if viewModel.showError {
                        Text(viewModel.errorMessage)
                            .font(.subheadline)
                            .foregroundStyle(.red)
                            .multilineTextAlignment(.center)
                            .padding(.horizontal, 16)
                    }

                    if let discordURL = URL(string: "https://discord.gg/bypass7proxys") {
                        Link(destination: discordURL) {
                            Label("Discord", systemImage: "bubble.left.and.bubble.right.fill")
                                .font(.subheadline.weight(.medium))
                                .foregroundStyle(AppTheme.accent)
                                .frame(maxWidth: .infinity)
                                .padding(.vertical, 11)
                                .background(
                                    AppTheme.accent.opacity(0.10),
                                    in: RoundedRectangle(cornerRadius: 11, style: .continuous)
                                )
                                .overlay {
                                    RoundedRectangle(cornerRadius: 11, style: .continuous)
                                        .strokeBorder(accent.opacity(0.30), lineWidth: 1)
                                }
                        }
                        .accessibilityLabel("Abrir Discord")
                        .padding(.horizontal, 8)
                    }

                    Spacer(minLength: 28)
                }
                .frame(maxWidth: .infinity)
                .padding(.horizontal, 28)
            }
            .scrollDismissesKeyboard(.interactively)
            .opacity(contentVisible ? 1 : 0)
            .offset(y: contentVisible ? 0 : 8)
        }
        .preferredColorScheme(.dark)
        .onTapGesture {
            isKeyFieldFocused = false
        }
        .onAppear {
            withAnimation(.easeOut(duration: 0.24)) {
                contentVisible = true
            }
        }
    }

    private func submit() {
        guard !viewModel.isLoading else { return }
        Task { await viewModel.login() }
    }
}


struct AuthenticatedRootView: View {
    @ObservedObject var viewModel: AuthenticationViewModel

    var body: some View {
        Group {
            if viewModel.isAuthenticated {
                ContentView()
            } else {
                LoginView(viewModel: viewModel)
            }
        }
        .animation(.easeInOut(duration: 0.2), value: viewModel.isAuthenticated)
    }
}
