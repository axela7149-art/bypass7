import SwiftUI
import UIKit
import UniformTypeIdentifiers

private enum PatchPackagePickerPolicy {
    static let packageType = UTType(filenameExtension: "3105") ?? .data
    static let allowedContentTypes: [UTType] = [packageType, .data]
    static let copiesSelectedDocument = true
}

struct PatchProjectsView: View {
    @StateObject private var store = PatchProjectStore()

    var body: some View {
        InjectFeaturesView(store: store)
    }
}

private struct InjectFeaturesView: View {
    private enum GameEdition: Equatable {
        case max
        case normal

        var label: String {
            switch self {
            case .max: return "MAX"
            case .normal: return "NORMAL"
            }
        }
    }

    private enum Preset: CaseIterable, Identifiable {
        case hsGirafa
        case hsCearense
        case hsPescocoAntena
        case hsPeitoAntena
        case assemblyLocalConfig

        var id: UUID {
            switch self {
            case .hsGirafa: return UUID(uuidString: "1D155BC4-EA29-4FFB-9B6F-EAB698C503E0")!
            case .hsCearense: return UUID(uuidString: "C11E1C4D-CAC4-4FC7-ACF2-4E6BECA09C01")!
            case .hsPescocoAntena: return UUID(uuidString: "C11E1C4D-CAC4-4FC7-ACF2-4E6BECA09C02")!
            case .hsPeitoAntena: return UUID(uuidString: "C11E1C4D-CAC4-4FC7-ACF2-4E6BECA09C03")!
            case .assemblyLocalConfig: return UUID(uuidString: "68E957C2-098C-4799-8017-333F46ECB254")!
            }
        }

        var title: String {
            switch self {
            case .hsGirafa: return "HS GIRAFA"
            case .hsCearense: return "HS CEARENSE"
            case .hsPescocoAntena: return "HS PESCOÇO + ANTENA"
            case .hsPeitoAntena: return "HS PEITO + ANTENA"
            case .assemblyLocalConfig: return "MENU AIM SILENT TESTE"
            }
        }

        var symbol: String { isDocumentsPreset ? "doc.text.fill" : "scope" }
        var isDocumentsPreset: Bool {
            switch self {
            case .assemblyLocalConfig: return true
            default: return false
            }
        }
        var edition: GameEdition { .normal }
    }

    private enum FeatureState: Equatable {
        case unknown
        case inactive
        case active(PatchTransactionReceipt)
        case working(isOn: Bool)

        var isOn: Bool {
            if case .active = self { return true }
            if case .working(let isOn) = self { return isOn }
            return false
        }

        var isWorking: Bool {
            if case .working = self { return true }
            return false
        }
    }

    @Environment(\.appLanguage) private var language
    @ObservedObject var store: PatchProjectStore
    @State private var states: [UUID: FeatureState] = [:]
    @State private var actionAlert: PatchStoreAlert?
    @State private var isPatchOperationInFlight = false
    @State private var pendingAutoApplyFor: UUID?
    @State private var selectedEdition: GameEdition = .normal

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: AppTheme.sectionSpacing) {
                    header
                    editionPicker
                    featureSection("FUNÇÕES DE AIMBOT") {
                        ForEach(Preset.allCases.filter { !$0.isDocumentsPreset }.sorted {
                            $0.title < $1.title
                        }) { preset in
                            presetRow(preset)
                        }
                    }
                    featureSection("menu") {
                        presetRow(.assemblyLocalConfig)
                    }

                }
                .padding(.horizontal, AppTheme.pageInset)
                .padding(.vertical, 16)
            }
            .background(Color.black.ignoresSafeArea())
            .animation(.easeInOut(duration: AppTheme.motionDuration), value: selectedEdition)
            .navigationTitle("INJETAR")
            .navigationBarTitleDisplayMode(.inline)
            .sheet(item: $store.passwordRequest, onDismiss: store.cancelUnlock) { _ in
                PatchUnlockView(store: store)
            }
            .alert(item: $store.alert) { alert in
                Alert(
                    title: Text(language.text(alert.titleKey)),
                    message: Text(alert.message(language: language)),
                    dismissButton: .default(Text(language.text("common.ok")))
                )
            }
            .alert(item: $actionAlert) { alert in
                Alert(
                    title: Text(language.text(alert.titleKey)),
                    message: Text(alert.message(language: language)),
                    dismissButton: .default(Text(language.text("common.ok")))
                )
            }
            .onAppear { resetToUnknown() }
        }
    }

    private var header: some View {
        VStack(alignment: .leading, spacing: 5) {
            Text("RECURSOS")
                .font(.caption.weight(.bold))
                .tracking(1.4)
                .foregroundStyle(AppTheme.accent)
            Text("Controle seus recursos")
                .font(.title3.weight(.semibold))
                .foregroundStyle(.white)
        }
    }

    private var editionPicker: some View {
        Picker("Edição do jogo", selection: $selectedEdition) {
            Text("FREE FIRE NORMAL").tag(GameEdition.normal)
            Text("FREE FIRE MAX").tag(GameEdition.max)
        }
        .pickerStyle(.segmented)
        .tint(AppTheme.accent)
    }

    private func featureSection<Content: View>(
        _ title: String,
        @ViewBuilder content: () -> Content
    ) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(title)
                .font(.caption.weight(.bold))
                .tracking(0.8)
                .foregroundStyle(.secondary)
                .padding(.horizontal, 4)
            VStack(spacing: 1) {
                content()
            }
            .background(
                Color.white.opacity(0.07),
                in: RoundedRectangle(cornerRadius: AppTheme.cardCornerRadius, style: .continuous)
            )
            .overlay {
                RoundedRectangle(cornerRadius: AppTheme.cardCornerRadius, style: .continuous)
                    .strokeBorder(AppTheme.surfaceBorder, lineWidth: 1)
            }
        }
    }

    private func presetRow(_ preset: Preset) -> some View {
        let state = states[preset.id] ?? .unknown
        let isLocked = false
        return HStack(spacing: 12) {
            AppRowIcon(systemName: isLocked ? "lock.doc.fill" : preset.symbol, tint: isLocked ? .secondary : AppTheme.accent, frameSize: 34)
            VStack(alignment: .leading, spacing: 3) {
                titleWithEdition(preset.title, edition: selectedEdition)
                if isLocked {
                    Text("BLOQUEADO")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                } else {
                    statusText(for: state)
                }
            }
            Spacer(minLength: 12)
            if state.isWorking {
                ProgressView()
                    .controlSize(.small)
                    .tint(AppTheme.accent)
            }
            Toggle("", isOn: toggleBinding(for: preset))
                .labelsHidden()
                .disabled(isLocked || state.isWorking || isPatchOperationInFlight || store.isBusy)
                .accessibilityLabel(preset.title)
        }
        .padding(.horizontal, 14)
        .padding(.vertical, 10)
        .contentShape(Rectangle())
    }

    private func titleWithEdition(_ title: String, edition: GameEdition) -> some View {
        HStack(spacing: 6) {
            Text(title)
                .font(.body.weight(.semibold))
                .foregroundStyle(.white)
                .lineLimit(1)

            Text(edition.label)
                .font(.system(size: 9, weight: .semibold, design: .rounded))
                .tracking(0.35)
                .foregroundStyle(edition == .max ? AppTheme.accent : Color.secondary)
                .padding(.horizontal, 6)
                .padding(.vertical, 2)
                .background(
                    edition == .max ? AppTheme.accent.opacity(0.16) : Color.white.opacity(0.08),
                    in: RoundedRectangle(cornerRadius: 5, style: .continuous)
                )
                .fixedSize()
        }
    }

    private func statusText(for state: FeatureState) -> some View {
        Group {
            switch state {
            case .unknown:
                Label("Estado não verificado", systemImage: "questionmark.circle")
            case .inactive:
                Text("Desativado")
            case .active:
                Text("Ativado nesta sessão")
            case .working(let isOn):
                Text(isOn ? "Aplicando…" : "Restaurando…")
            }
        }
        .font((state.isWorking || state.isOn) ? .caption.weight(.medium) : .caption)
        .foregroundStyle((state.isWorking || state.isOn) ? AppTheme.accent : .secondary)
    }

    private func toggleBinding(for preset: Preset) -> Binding<Bool> {
        Binding(
            get: { (states[preset.id] ?? .unknown).isOn },
            set: { requestedOn in
                performToggle(for: preset, requestedOn: requestedOn)
            }
        )
    }

    private func performToggle(for preset: Preset, requestedOn: Bool) {
        let current = states[preset.id] ?? .unknown
        guard !current.isWorking, !isPatchOperationInFlight, !store.isBusy else { return }

        if requestedOn {
            apply(preset)
        } else if case .active(let receipt) = current {
            restore(preset, receipt: receipt)
        }
    }

    private func apply(_ preset: Preset) {
        guard let item = store.items.first(where: { $0.id == preset.id }) else {
            actionAlert = PatchStoreAlert(titleKey: "common.failed", messageKey: "patch.error.invalid_project")
            return
        }
        guard !item.isLocked, let project = item.project else {
            if item.isOfficialPreset {
                pendingAutoApplyFor = preset.id
                store.requestUnlock(for: item) { [self] packageID, success in
                    guard packageID == pendingAutoApplyFor,
                          let preset = Preset.allCases.first(where: { $0.id == packageID })
                    else {
                        pendingAutoApplyFor = nil
                        return
                    }
                    pendingAutoApplyFor = nil
                    if success,
                       let unlocked = store.items.first(where: { $0.id == preset.id }),
                       !unlocked.isLocked {
                        apply(preset)
                    }
                }
            } else {
                store.requestUnlock(for: item)
            }
            return
        }

        let projectToApply = projectForSelectedEdition(project, preset: preset)
        states[preset.id] = .working(isOn: true)
        isPatchOperationInFlight = true
        Task.detached(priority: .userInitiated) {
            do {
                if preset.isDocumentsPreset,
                   let bundleID = projectToApply.bundleIdentifiers.first,
                   ContainerStore.resolveAppContainerPath(bundleID: bundleID) == nil {
                    throw PatchPackageError.targetAppUnavailable(bundleID)
                }
                let receipt = try DevicePatchService.apply(project: projectToApply)
                await MainActor.run {
                    states[preset.id] = .active(receipt)
                    isPatchOperationInFlight = false
                }
            } catch let error as PatchPackageError {
                await MainActor.run {
                    states[preset.id] = .unknown
                    isPatchOperationInFlight = false
                    actionAlert = PatchStoreAlert(
                        titleKey: "common.failed",
                        messageKey: error.localizationKey,
                        messageArgument: error.localizationArgument
                    )
                }
            } catch {
                await MainActor.run {
                    states[preset.id] = .unknown
                    isPatchOperationInFlight = false
                    actionAlert = PatchStoreAlert(titleKey: "common.failed", messageKey: "patch.error.apply")
                }
            }
        }
    }

    private func projectForSelectedEdition(_ project: PatchProject, preset: Preset) -> PatchProject {
        guard preset.isDocumentsPreset else { return project }
        let supportedBundleIDs: Set<String> = ["com.dts.freefireth", "com.dts.freefiremax"]
        guard !project.allBundleIdentifiers.isEmpty,
              project.allBundleIdentifiers.allSatisfy({ supportedBundleIDs.contains($0) }) else {
            return project
        }

        let selectedBundleID = selectedEdition == .max
            ? "com.dts.freefiremax"
            : "com.dts.freefireth"
        var selectedProject = project
        selectedProject.bundleIdentifiers = project.bundleIdentifiers.map { _ in selectedBundleID }
        selectedProject.directories = project.directories.map { directory in
            var copy = directory
            copy.bundleID = selectedBundleID
            return copy
        }
        selectedProject.rules = project.rules.map { rule in
            var copy = rule
            copy.bundleID = selectedBundleID
            return copy
        }
        return selectedProject
    }

    private func restore(_ preset: Preset, receipt: PatchTransactionReceipt) {
        states[preset.id] = .working(isOn: false)
        isPatchOperationInFlight = true
        Task.detached(priority: .userInitiated) {
            do {
                try DevicePatchService.restore(receipt: receipt)
                await MainActor.run {
                    states[preset.id] = .inactive
                    isPatchOperationInFlight = false
                }
            } catch let error as PatchPackageError {
                await MainActor.run {
                    states[preset.id] = .active(receipt)
                    isPatchOperationInFlight = false
                    actionAlert = PatchStoreAlert(
                        titleKey: "common.failed",
                        messageKey: error.localizationKey,
                        messageArgument: error.localizationArgument
                    )
                }
            } catch {
                await MainActor.run {
                    states[preset.id] = .active(receipt)
                    isPatchOperationInFlight = false
                    actionAlert = PatchStoreAlert(titleKey: "common.failed", messageKey: "patch.error.restore")
                }
            }
        }
    }

    private func resetToUnknown() {
        for preset in Preset.allCases where states[preset.id] == nil {
            states[preset.id] = .unknown
        }
    }
}

private struct PatchProjectRow: View {
    let item: PatchLibraryItem
    let language: AppLanguage

    var body: some View {
        HStack(spacing: 12) {
            AppRowIcon(systemName: item.isLocked ? "lock.doc.fill" : "shippingbox.fill")
            VStack(alignment: .leading, spacing: 3) {
                Text(item.project?.name ?? language.text("patch.locked_project"))
                    .font(.body.weight(.semibold))
                    .foregroundStyle(.primary)
                Text(item.isLocked
                     ? language.text("patch.tap_to_unlock")
                     : language.text(
                        item.summary.schemaVersion >= 2 ? "patch.workspace_items_count" : "patch.rules_count",
                        Int64((item.project?.rules.count ?? 0) + (item.project?.directories.count ?? 0))
                     ))
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
            Spacer()
            if item.summary.isPasswordProtected {
                Image(systemName: "key.fill")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .accessibilityLabel(language.text("patch.password_protected"))
            }
        }
        .padding(.vertical, 4)
    }
}

private struct PatchUnlockView: View {
    @Environment(\.appLanguage) private var language
    @Environment(\.dismiss) private var dismiss
    @ObservedObject var store: PatchProjectStore
    @State private var password = ""

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    SecureField(language.text("patch.password"), text: $password)
                        .textContentType(.password)
                        .submitLabel(.done)
                        .onSubmit(unlock)
                        .onChange(of: password) { _ in
                            store.clearUnlockError()
                        }
                    if let errorKey = store.unlockErrorKey {
                        Text(language.text(errorKey))
                            .font(.footnote)
                            .foregroundStyle(.red)
                    }
                } footer: {
                    Text(language.text("patch.password_once_message"))
                }
            }
            .navigationTitle(language.text("patch.unlock"))
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button(language.text("common.cancel")) { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button(language.text("patch.unlock"), action: unlock)
                        .disabled(password.isEmpty || store.isBusy)
                }
            }
        }
    }

    private func unlock() {
        guard !password.isEmpty else { return }
        store.unlock(password: password)
    }
}

private struct PatchProjectDetailView: View {
    @Environment(\.appLanguage) private var language
    @ObservedObject var store: PatchProjectStore
    let projectID: UUID
    @State private var showEditor = false
    @State private var editingRule: PatchRule?
    @State private var showApplyConfirmation = false
    @State private var showRestoreConfirmation = false
    @State private var isWorking = false
    @State private var actionAlert: PatchStoreAlert?
    @State private var shareRequest: PatchShareRequest?

    private var item: PatchLibraryItem? {
        store.items.first(where: { $0.id == projectID })
    }

    private var receipt: PatchTransactionReceipt? {
        DevicePatchService.latestReceipt(projectID: projectID)
    }

    private var isWorkspaceProject: Bool {
        (item?.summary.schemaVersion ?? 1) >= 2
    }

    private var isOfficialProject: Bool {
        item?.isOfficialPreset ?? false
    }

    var body: some View {
        List {
            if let item, let project = item.project {
                if isWorkspaceProject {
                    Section {
                        ForEach(project.allBundleIdentifiers, id: \.self) { bundleID in
                            Label {
                                Text(bundleID)
                                    .font(.subheadline.monospaced())
                            } icon: {
                                Image(systemName: "app.dashed")
                                    .foregroundStyle(AppTheme.accent)
                            }
                        }
                        LabeledContent(language.text("patch.files")) {
                            Text("\(project.rules.count)")
                        }
                        LabeledContent(language.text("patch.folders")) {
                            Text("\(project.directories.count)")
                        }
                        if let workspaceURL = item.workspaceURL {
                            NavigationLink {
                                FileBrowserView(
                                    containerPath: workspaceURL.path,
                                    title: project.name,
                                    bundleID: nil
                                )
                            } label: {
                                Label(
                                    language.text("patch.open_workspace"),
                                    systemImage: "folder"
                                )
                            }
                        }
                    } header: {
                        Text(language.text("patch.workspace"))
                    } footer: {
                        Text(language.text("patch.workspace_detail_footer"))
                    }
                } else {
                    Section {
                        ForEach(project.rules) { rule in
                            ruleRow(rule)
                        }
                    } header: {
                        Text(language.text("patch.rules"))
                    } footer: {
                        Text(language.text("patch.legacy_footer"))
                    }
                }

                Section(language.text("patch.password")) {
                    HStack(spacing: 12) {
                        Image(systemName: item.summary.isPasswordProtected ? "lock.fill" : "lock.open")
                            .foregroundStyle(AppTheme.accent)
                            .frame(width: 24)
                        Text(language.text(item.summary.isPasswordProtected
                            ? "patch.password_locked"
                            : "patch.no_password"))
                            .font(.subheadline)
                    }
                }

                Section {
                    Button {
                        showApplyConfirmation = true
                    } label: {
                        actionLabel("patch.apply", systemImage: "checkmark.shield.fill")
                    }
                    .disabled(isWorking)

                    if receipt != nil {
                        Button(role: .destructive) {
                            showRestoreConfirmation = true
                        } label: {
                            actionLabel("patch.restore", systemImage: "arrow.uturn.backward.circle")
                        }
                        .disabled(isWorking)
                    }

                    if !isOfficialProject {
                        Button(action: prepareExport) {
                            actionLabel("patch.export", systemImage: "square.and.arrow.up")
                        }
                        .disabled(isWorking)
                    }
                } footer: {
                    Text(language.text("patch.apply_footer"))
                }
            }
        }
        .listStyle(.insetGrouped)
        .navigationTitle(item?.project?.name ?? language.text("patch.title"))
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .navigationBarTrailing) {
                if isWorking {
                    ProgressView()
                } else if !isWorkspaceProject && !isOfficialProject {
                    Button(language.text("patch.edit")) { showEditor = true }
                        .disabled(item?.project == nil)
                }
            }
        }
        .sheet(isPresented: $showEditor) {
            if let item, let project = item.project {
                PatchProjectEditorView(
                    existingProject: project,
                    passwordIsProtected: item.summary.isPasswordProtected
                ) { updatedProject, _ in
                    store.update(project: updatedProject)
                }
            }
        }
        .sheet(item: $editingRule) { rule in
            PatchRuleEditorView(rule: rule) { updatedRule in
                updateRule(updatedRule)
            }
        }
        .confirmationDialog(
            language.text("patch.apply_confirm_title"),
            isPresented: $showApplyConfirmation,
            titleVisibility: .visible
        ) {
            Button(language.text("patch.apply")) { apply() }
            Button(language.text("common.cancel"), role: .cancel) {}
        } message: {
            Text(language.text("patch.apply_confirm_message"))
        }
        .confirmationDialog(
            language.text("patch.restore_confirm_title"),
            isPresented: $showRestoreConfirmation,
            titleVisibility: .visible
        ) {
            Button(language.text("patch.restore"), role: .destructive) { restore() }
            Button(language.text("common.cancel"), role: .cancel) {}
        }
        .alert(item: $actionAlert) { alert in
            Alert(
                title: Text(language.text(alert.titleKey)),
                message: Text(alert.message(language: language)),
                dismissButton: .default(Text(language.text("common.ok")))
            )
        }
        .sheet(item: $shareRequest) { request in
            PatchActivityView(items: [request.url])
                .ignoresSafeArea()
        }
    }

    private func actionLabel(_ key: String, systemImage: String) -> some View {
        Label(language.text(key), systemImage: systemImage)
            .frame(maxWidth: .infinity, alignment: .leading)
    }

    @ViewBuilder
    private func ruleRow(_ rule: PatchRule) -> some View {
        if isOfficialProject {
            HStack(spacing: 10) {
                ruleSummary(rule)
            }
            .contentShape(Rectangle())
        } else {
            Button {
                editingRule = rule
            } label: {
                HStack(spacing: 10) {
                    ruleSummary(rule)
                    Spacer(minLength: 8)
                    Image(systemName: "chevron.right")
                        .font(.caption.weight(.semibold))
                        .foregroundStyle(.tertiary)
                }
                .contentShape(Rectangle())
            }
            .buttonStyle(.plain)
            .accessibilityHint(language.text("patch.edit_rule_hint"))
        }
    }

    private func ruleSummary(_ rule: PatchRule) -> some View {
        VStack(alignment: .leading, spacing: 5) {
            Text(rule.bundleID)
                .font(.subheadline.weight(.semibold))
                .foregroundStyle(.primary)
            Text(rule.relativePath)
                .font(.caption.monospaced())
                .foregroundStyle(.secondary)
                .lineLimit(2)
            Label(rule.replacementFilename, systemImage: "arrow.triangle.2.circlepath")
                .font(.caption)
                .foregroundStyle(AppTheme.accent)
        }
        .padding(.vertical, 3)
    }

    private func updateRule(_ updatedRule: PatchRule) {
        guard var project = item?.project,
              let index = project.rules.firstIndex(where: { $0.id == updatedRule.id }) else {
            return
        }
        project.rules[index] = updatedRule
        project.updatedAt = Date()
        do {
            try PatchPackageCodec.validate(project)
            store.update(project: project)
        } catch let error as PatchPackageError {
            actionAlert = PatchStoreAlert(
                titleKey: "common.failed",
                messageKey: error.localizationKey,
                messageArgument: error.localizationArgument
            )
        } catch {
            actionAlert = PatchStoreAlert(
                titleKey: "common.failed",
                messageKey: "patch.error.invalid_project"
            )
        }
    }

    private func apply() {
        guard let item, let baseProject = item.project else { return }
        isWorking = true
        Task.detached(priority: .userInitiated) {
            do {
                let project = item.summary.schemaVersion >= 2
                    ? try PatchProjectLibrary.synchronizeWorkspace(item: item)
                    : baseProject
                _ = try DevicePatchService.apply(project: project)
                await MainActor.run {
                    store.reload()
                    isWorking = false
                    actionAlert = PatchStoreAlert(titleKey: "common.done", messageKey: "patch.applied_message")
                }
            } catch let error as PatchPackageError {
                await MainActor.run {
                    isWorking = false
                    actionAlert = PatchStoreAlert(
                        titleKey: "common.failed",
                        messageKey: error.localizationKey,
                        messageArgument: error.localizationArgument
                    )
                }
            } catch {
                await MainActor.run {
                    isWorking = false
                    actionAlert = PatchStoreAlert(titleKey: "common.failed", messageKey: "patch.error.apply")
                }
            }
        }
    }

    private func prepareExport() {
        guard let item else { return }
        isWorking = true
        Task.detached(priority: .userInitiated) {
            do {
                if item.summary.schemaVersion >= 2 {
                    _ = try PatchProjectLibrary.synchronizeWorkspace(item: item)
                }
                await MainActor.run {
                    store.reload()
                    isWorking = false
                    shareRequest = PatchShareRequest(url: item.packageURL)
                }
            } catch let error as PatchPackageError {
                await MainActor.run {
                    isWorking = false
                    actionAlert = PatchStoreAlert(
                        titleKey: "common.failed",
                        messageKey: error.localizationKey,
                        messageArgument: error.localizationArgument
                    )
                }
            } catch {
                await MainActor.run {
                    isWorking = false
                    actionAlert = PatchStoreAlert(
                        titleKey: "common.failed",
                        messageKey: "patch.error.invalid_project"
                    )
                }
            }
        }
    }

    private func restore() {
        guard let receipt else { return }
        isWorking = true
        Task.detached(priority: .userInitiated) {
            do {
                try DevicePatchService.restore(receipt: receipt)
                await MainActor.run {
                    isWorking = false
                    actionAlert = PatchStoreAlert(titleKey: "common.done", messageKey: "patch.restored_message")
                }
            } catch let error as PatchPackageError {
                await MainActor.run {
                    isWorking = false
                    actionAlert = PatchStoreAlert(
                        titleKey: "common.failed",
                        messageKey: error.localizationKey,
                        messageArgument: error.localizationArgument
                    )
                }
            } catch {
                await MainActor.run {
                    isWorking = false
                    actionAlert = PatchStoreAlert(titleKey: "common.failed", messageKey: "patch.error.restore")
                }
            }
        }
    }
}

private struct PatchShareRequest: Identifiable {
    let id = UUID()
    let url: URL
}

private struct PatchActivityView: UIViewControllerRepresentable {
    let items: [Any]

    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: items, applicationActivities: nil)
    }

    func updateUIViewController(
        _ uiViewController: UIActivityViewController,
        context: Context
    ) {}
}
