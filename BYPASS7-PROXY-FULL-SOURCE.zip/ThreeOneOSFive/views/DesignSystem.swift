import SwiftUI
import UIKit

/// Builds a color that automatically resolves for the active interface style,
/// so the whole app can flip between the light and dark looks with a single
/// `.preferredColorScheme(...)` change.
private func themeColor(light: UIColor, dark: UIColor) -> UIColor {
    UIColor { traits in
        traits.userInterfaceStyle == .dark ? dark : light
    }
}

enum AppTheme {
    // MARK: Brand

    /// BYPASS7 accent red, brightened slightly for the dark theme.
    static let accent = Color(
        uiColor: themeColor(
            light: UIColor(red: 0.86, green: 0.04, blue: 0.08, alpha: 1.00),
            dark: UIColor(red: 1.00, green: 0.16, blue: 0.20, alpha: 1.00)
        )
    )
    static let accentSoft = accent.opacity(0.14)
    static let accentBorder = accent.opacity(0.28)

    // MARK: Surfaces

    static let pageBackground = Color(
        uiColor: themeColor(
            light: UIColor(red: 0.000, green: 0.000, blue: 0.000, alpha: 1.00),
            dark: UIColor(red: 0.000, green: 0.000, blue: 0.000, alpha: 1.00)
        )
    )
    static let consoleBackground = Color(
        uiColor: themeColor(
            light: UIColor(red: 0.015, green: 0.015, blue: 0.015, alpha: 1.00),
            dark: UIColor(red: 0.015, green: 0.015, blue: 0.015, alpha: 1.00)
        )
    )
    static let surface = Color(
        uiColor: themeColor(
            light: UIColor(white: 1.0, alpha: 0.070),
            dark: UIColor(white: 1.0, alpha: 0.070)
        )
    )
    static let surfaceBorder = Color(
        uiColor: themeColor(
            light: UIColor(white: 1.0, alpha: 0.120),
            dark: UIColor(white: 1.0, alpha: 0.120)
        )
    )

    /// Fill used by rounded cards.
    static let cardFill = Color(
        uiColor: themeColor(
            light: UIColor(white: 1.0, alpha: 0.060),
            dark: UIColor(white: 1.0, alpha: 0.060)
        )
    )
    static let cardBorder = Color(
        uiColor: themeColor(
            light: UIColor(white: 1.0, alpha: 0.100),
            dark: UIColor(white: 1.0, alpha: 0.100)
        )
    )

    /// Neutral gray used by disabled controls.
    static let disabledFill = Color(
        uiColor: themeColor(
            light: UIColor(white: 0.0, alpha: 0.100),
            dark: UIColor(white: 1.0, alpha: 0.140)
        )
    )

    // MARK: Motion

    static let motionDuration: Double = 0.22

    // MARK: Layout metrics

    static let pageInset: CGFloat = 16
    static let sectionSpacing: CGFloat = 18
    static let cardCornerRadius: CGFloat = 12
    static let rowVerticalPadding: CGFloat = 11
    static let rowIconSize: CGFloat = 17
    static let rowIconFrame: CGFloat = 28
    static let fileRowIconSize: CGFloat = 17
    static let fileRowIconFrame: CGFloat = 30
    static let fileRowHeight: CGFloat = 56
    static let appIconSize: CGFloat = 32
    static let emptyIconSize: CGFloat = 30
    static let selectionIconSize: CGFloat = 18
}

// MARK: - Rounded card

/// Reusable rounded card container used across the redesigned screens.
struct AppCard<Content: View>: View {
    var padding: CGFloat
    var cornerRadius: CGFloat
    private let content: Content

    init(
        padding: CGFloat = 16,
        cornerRadius: CGFloat = AppTheme.cardCornerRadius,
        @ViewBuilder content: () -> Content
    ) {
        self.padding = padding
        self.cornerRadius = cornerRadius
        self.content = content()
    }

    var body: some View {
        content
            .padding(padding)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(
                AppTheme.cardFill,
                in: RoundedRectangle(cornerRadius: cornerRadius, style: .continuous)
            )
            .overlay(
                RoundedRectangle(cornerRadius: cornerRadius, style: .continuous)
                    .strokeBorder(AppTheme.cardBorder, lineWidth: 1)
            )
    }
}

// MARK: - Segmented / pill control

/// Pill-style segmented control bound to a `Hashable` selection.
struct AppSegmentedControl<Item: Hashable>: View {
    let items: [Item]
    @Binding var selection: Item
    let title: (Item) -> String

    var body: some View {
        HStack(spacing: 4) {
            ForEach(items, id: \.self) { item in
                let isSelected = selection == item
                Button {
                    withAnimation(.easeInOut(duration: AppTheme.motionDuration)) {
                        selection = item
                    }
                } label: {
                    Text(title(item))
                        .font(.subheadline.weight(.semibold))
                        .foregroundStyle(isSelected ? Color.white : Color.secondary)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 8)
                        .background(
                            isSelected ? AppTheme.accent : Color.clear,
                            in: Capsule(style: .continuous)
                        )
                        .contentShape(Capsule())
                }
                .buttonStyle(.plain)
                .accessibilityAddTraits(isSelected ? .isSelected : [])
            }
        }
        .padding(4)
        .background(AppTheme.surface, in: Capsule(style: .continuous))
        .overlay(
            Capsule(style: .continuous)
                .strokeBorder(AppTheme.surfaceBorder, lineWidth: 1)
        )
    }
}

// MARK: - Row with toggle

/// Standardized row pairing an icon + label with a trailing toggle.
struct AppToggleRow: View {
    let title: String
    var subtitle: String? = nil
    var systemImage: String? = nil
    /// Optional override for the leading icon tint (e.g. a color swatch).
    var iconTint: Color? = nil
    @Binding var isOn: Bool
    var isDisabled: Bool = false

    var body: some View {
        HStack(spacing: 12) {
            if let systemImage {
                AppRowIcon(
                    systemName: systemImage,
                    tint: iconTint ?? (isDisabled ? .secondary : AppTheme.accent),
                    frameSize: 34
                )
            }

            VStack(alignment: .leading, spacing: 2) {
                Text(title)
                    .font(.body.weight(.medium))
                    .foregroundStyle(isDisabled ? Color.secondary : Color.primary)
                if let subtitle {
                    Text(subtitle)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            }

            Spacer(minLength: 8)

            Toggle("", isOn: $isOn)
                .labelsHidden()
                .tint(AppTheme.accent)
                .disabled(isDisabled)
        }
        .padding(.vertical, AppTheme.rowVerticalPadding)
        .contentShape(Rectangle())
    }
}

// MARK: - Warning banner

struct AppWarningBanner: View {
    let title: String
    var message: String? = nil
    var systemImage: String = "exclamationmark.triangle.fill"
    var tint: Color = .orange

    var body: some View {
        HStack(alignment: .top, spacing: 10) {
            Image(systemName: systemImage)
                .font(.system(size: 15, weight: .semibold))
                .foregroundStyle(tint)

            VStack(alignment: .leading, spacing: 3) {
                Text(title)
                    .font(.subheadline.weight(.semibold))
                    .foregroundStyle(.primary)
                if let message {
                    Text(message)
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                }
            }

            Spacer(minLength: 0)
        }
        .padding(12)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(
            tint.opacity(0.12),
            in: RoundedRectangle(cornerRadius: 10, style: .continuous)
        )
        .overlay(
            RoundedRectangle(cornerRadius: 10, style: .continuous)
                .strokeBorder(tint.opacity(0.28), lineWidth: 1)
        )
    }
}

// MARK: - Buttons

/// Primary filled action button.
struct AppPrimaryButton: View {
    let title: String
    var systemImage: String? = nil
    var isLoading: Bool = false
    var isDisabled: Bool = false
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            HStack(spacing: 8) {
                if isLoading {
                    ProgressView().tint(.white)
                } else if let systemImage {
                    Image(systemName: systemImage)
                }
                Text(title)
            }
            .font(.headline)
            .foregroundStyle(Color.white)
            .frame(maxWidth: .infinity)
            .padding(.vertical, 14)
            .background(
                isDisabled ? AppTheme.disabledFill : AppTheme.accent,
                in: RoundedRectangle(cornerRadius: 12, style: .continuous)
            )
        }
        .disabled(isDisabled || isLoading)
        .buttonStyle(AppPressableButtonStyle())
    }
}

/// Non-interactive gray button/label, used for unavailable actions.
struct AppDisabledButton: View {
    let title: String
    var systemImage: String? = nil

    var body: some View {
        HStack(spacing: 8) {
            if let systemImage {
                Image(systemName: systemImage)
            }
            Text(title)
        }
        .font(.headline)
        .foregroundStyle(.secondary)
        .frame(maxWidth: .infinity)
        .padding(.vertical, 14)
        .background(
            AppTheme.disabledFill,
            in: RoundedRectangle(cornerRadius: 12, style: .continuous)
        )
    }
}

// MARK: - Device avatar

/// Free Fire style device avatar badge shown in the tab header. Falls back to a
/// stylized placeholder (no avatar art is bundled) so the layout stays stable.
struct AppAvatar: View {
    var size: CGFloat = 38

    var body: some View {
        ZStack {
            Circle()
                .fill(
                    LinearGradient(
                        colors: [AppTheme.accent, AppTheme.accent.opacity(0.55)],
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    )
                )
            Image(systemName: "person.fill")
                .font(.system(size: size * 0.44, weight: .semibold))
                .foregroundStyle(.white)
        }
        .frame(width: size, height: size)
        .overlay(
            Circle().strokeBorder(Color.white.opacity(0.22), lineWidth: 1)
        )
        .shadow(color: AppTheme.accent.opacity(0.35), radius: 6, x: 0, y: 3)
        .accessibilityHidden(true)
    }
}

// MARK: - App background (art + watermark)

/// Full-screen backdrop: theme background color, the `bypass7.icon` art at low
/// opacity, the BYPASS7 logo as a faint watermark and a discreet wordmark on
/// the dark theme. Never intercepts touches.
struct AppBackgroundView: View {
    @Environment(\.colorScheme) private var colorScheme

    var body: some View {
        GeometryReader { proxy in
            ZStack {
                AppTheme.pageBackground

                if let art = UIImage(named: "bypass7.icon") {
                    Image(uiImage: art)
                        .resizable()
                        .scaledToFill()
                        .frame(width: proxy.size.width, height: proxy.size.height)
                        .clipped()
                        .opacity(colorScheme == .dark ? 0.20 : 0.12)
                        .brightness(colorScheme == .dark ? -0.28 : 0.04)
                }

                if let logo = UIImage(named: "Bypass7Logo") {
                    Image(uiImage: logo)
                        .resizable()
                        .scaledToFit()
                        .frame(width: proxy.size.width * 0.72)
                        .opacity(0.05)
                        .frame(width: proxy.size.width, height: proxy.size.height)
                }

                if colorScheme == .dark {
                    Text("BYPASS7PROXY")
                        .font(.system(size: 62, weight: .black, design: .rounded))
                        .kerning(2)
                        .foregroundStyle(Color.white.opacity(0.035))
                        .rotationEffect(.degrees(-16))
                        .lineLimit(1)
                        .minimumScaleFactor(0.4)
                        .frame(width: proxy.size.width * 0.9)
                        .frame(width: proxy.size.width, height: proxy.size.height)
                }
            }
        }
        .ignoresSafeArea()
        .allowsHitTesting(false)
    }
}

// MARK: - Existing shared components

struct AppRowIcon: View {
    let systemName: String
    var tint: Color = AppTheme.accent
    var symbolSize: CGFloat = AppTheme.rowIconSize
    var frameSize: CGFloat = AppTheme.rowIconFrame

    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 6, style: .continuous)
                .fill(tint.opacity(0.12))
            Image(systemName: systemName)
                .font(.system(size: symbolSize, weight: .medium))
                .foregroundStyle(tint)
        }
        .frame(width: frameSize, height: frameSize)
        .accessibilityHidden(true)
    }
}

struct AppPressableButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .scaleEffect(configuration.isPressed ? 0.985 : 1)
            .opacity(configuration.isPressed ? 0.92 : 1)
            .animation(.easeOut(duration: AppTheme.motionDuration), value: configuration.isPressed)
    }
}

struct AppSearchField: View {
    @Binding var text: String
    let prompt: String
    let clearLabel: String

    var body: some View {
        HStack(spacing: 8) {
            Image(systemName: "magnifyingglass")
                .font(.system(size: 14, weight: .medium))
                .foregroundStyle(.secondary)
                .accessibilityHidden(true)

            TextField(prompt, text: $text)
                .font(.body)
                .textInputAutocapitalization(.never)
                .autocorrectionDisabled()
                .submitLabel(.search)

            if !text.isEmpty {
                Button {
                    text = ""
                } label: {
                    Image(systemName: "xmark.circle.fill")
                        .font(.system(size: 14, weight: .medium))
                        .foregroundStyle(.tertiary)
                }
                .buttonStyle(.plain)
                .accessibilityLabel(clearLabel)
            }
        }
        .padding(.horizontal, 11)
        .frame(minHeight: 36)
        .background(
            Color(uiColor: .secondarySystemFill),
            in: RoundedRectangle(cornerRadius: 10, style: .continuous)
        )
        .padding(.horizontal, AppTheme.pageInset)
        .padding(.vertical, 8)
        .background(.bar)
    }
}

struct AppLogo: View {
    var size: CGFloat = 44

    var body: some View {
        Group {
            if let icon = UIImage(named: "Bypass7Logo")
                ?? UIImage(named: "AppIcon60x60")
                ?? Bundle.main.path(forResource: "AppIcon60x60@2x", ofType: "png").flatMap(UIImage.init(contentsOfFile:))
                ?? UIImage(named: "AppIcon") {
                Image(uiImage: icon)
                    .resizable()
                    .scaledToFill()
            } else {
                Image(systemName: "slider.horizontal.3")
                    .font(.title2.weight(.semibold))
                    .foregroundStyle(.white)
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                    .background(AppTheme.accent)
            }
        }
        .frame(width: size, height: size)
        .clipShape(RoundedRectangle(cornerRadius: size * 0.30, style: .continuous))
        .accessibilityHidden(true)
    }
}
