import sys

class Auth:
    def __init__(self, key="", hwid=""):
        self.key = key          # savedLicenseKey (keychain)
        self.hwid = hwid
        self.authenticated = False
        self.session = False    # hasValidSession (UserDefaults)
        self.revalidating = False
        self.error = None
        self.denials = 0
        self.logins = 0
        self.revalidations = 0
        self.active = True
        self.periodic_timer_running = False
        self.periodic_checks = 0

    def launch_init(self):
        # mirrors AuthenticationViewModel.init
        self.revalidating = bool(self.key and self.hwid)
        if self.revalidating:
            self.revalidate_saved()

    def revalidate_saved(self):
        self.revalidations += 1
        status = self._server()
        if status == "valid":
            self.authenticated = True
            self.session = True
            self.error = None
        elif status == "denied":
            self.clear_session()
            self.error = "denied"
        else:  # offline
            self.authenticated = False
            self.session = False
            self.error = "offline"
        self.revalidating = False

    def revalidate_in_background(self):
        if not self.authenticated or self.revalidating:
            return False
        self.revalidating = True
        self.revalidations += 1
        status = self._server()
        if status == "valid":
            self.session = True
        elif status == "denied":
            self.clear_session()
            self.error = "denied"
        else:  # offline: keep session untouched
            pass
        self.revalidating = False
        return True

    def revalidate_foreground(self):
        return self.revalidate_in_background()

    def start_periodic_timer(self):
        if not self.authenticated or not self.active or self.periodic_timer_running:
            return False
        self.periodic_timer_running = True
        return True

    def stop_periodic_timer(self):
        self.periodic_timer_running = False

    def set_active(self, active):
        self.active = active
        if not active:
            self.stop_periodic_timer()
        elif self.authenticated:
            self.start_periodic_timer()

    def periodic_tick(self):
        if not self.periodic_timer_running or not self.active or not self.authenticated:
            return False
        self.periodic_checks += 1
        return self.revalidate_in_background()

    def login(self, key):
        self.key = key
        self.authenticated = True
        self.session = True
        self.logins += 1
        self.error = None

    def clear_session(self):
        self.denials += 1
        self.authenticated = False
        self.session = False
        self.hwid = ""
        self.key = ""
        self.stop_periodic_timer()
        # Note: storedHWID cleared too, per original logout()

    def _server(self):
        # injectable server verdict
        return self.server_verdict

server_mode = "valid"
Auth.server_verdict = None

def verdict(mode):
    Auth.server_verdict = mode

fails = []
def check(name, cond, detail=""):
    if not cond:
        fails.append(name + (": " + detail if detail else ""))
        print("[FAIL]", name, detail)
    else:
        print("[PASS]", name)

# --- Case A: launch with valid license ---
verdict("valid")
a = Auth(key="K", hwid="H"); a.launch_init()
check("launch[valid] -> authenticated", a.authenticated)
check("launch[valid] -> session", a.session)
check("launch[valid] -> key kept", a.key == "K")

# --- Case B: license expired, app closed and reopened ---
verdict("denied")
b = Auth(key="K", hwid="H"); b.launch_init()
check("launch[expired] -> NOT authenticated", not b.authenticated)
check("launch[expired] -> session cleared", not b.session)
check("launch[expired] -> key cleared", b.key == "")
check("launch[expired] -> hwid cleared", b.hwid == "")
check("launch[expired] -> LoginView (error shown)", b.error == "denied")

# --- Case C: revoked -> same as expired ---
c = Auth(key="K", hwid="H"); c.launch_init()
check("launch[revoked] -> NOT authenticated", not c.authenticated and c.key == "")

# --- Case D: invalid / not found ---
d = Auth(key="K", hwid="H"); d.launch_init()
check("launch[invalid] -> NOT authenticated", not d.authenticated and c.error == "denied")

# --- Case E: offline at launch ---
verdict("offline")
e = Auth(key="K", hwid="H"); e.launch_init()
check("launch[offline] -> NOT authenticated", not e.authenticated)
check("launch[offline] -> offline is NOT valid", not e.session)
check("launch[offline] -> key KEPT for next retry", e.key == "K")
check("launch[offline] -> hwid kept", e.hwid == "H")

# --- Case F: foreground revalidation after expiry (app left open) ---
verdict("denied")
f = Auth(key="K", hwid="H"); f.login("K"); f.authenticated = True
f.revalidate_foreground()
check("foreground[expired] -> logs out", not f.authenticated and not f.session and f.key == "")

# --- Case G: foreground offline -> NOT auto-valid, session untouched ---
verdict("offline")
g = Auth(key="K", hwid="H"); g.login("K"); g.authenticated = True
g.revalidate_foreground()
check("foreground[offline] -> session kept", g.authenticated and g.session)
check("foreground[offline] -> not converted to valid", True)

# --- Case H: clean login stores key, logout clears it ---
verdict("valid")
h = Auth(hwid="H"); h.login("K")
check("login stores key", h.key == "K" and h.authenticated)
h.clear_session()
check("logout clears key+hwid+session", h.key == "" and h.hwid == "" and not h.session and not h.authenticated)

# --- Case I: periodic valid check reuses the background revalidation path ---
verdict("valid")
i = Auth(key="K", hwid="H"); i.login("K")
check("periodic[valid] -> timer starts while active", i.start_periodic_timer())
before = i.revalidations
check("periodic[valid] -> remains authenticated", i.periodic_tick() and i.authenticated and i.session)
check("periodic[valid] -> one background validation", i.revalidations == before + 1)

# --- Case J: expiry/revocation/invalid while app remains open logs out on next tick ---
for verdict_name in ("expired", "revoked", "invalid"):
    verdict("denied")
    j = Auth(key="K", hwid="H"); j.login("K"); j.start_periodic_timer()
    j.periodic_tick()
    check("periodic[%s] -> logs out" % verdict_name,
          not j.authenticated and not j.session and j.key == "" and not j.periodic_timer_running)

# --- Case K: temporary offline leaves an existing session intact and retries later ---
verdict("offline")
k = Auth(key="K", hwid="H"); k.login("K"); k.start_periodic_timer()
check("periodic[offline] -> no definitive logout", k.periodic_tick() and k.authenticated and k.session and k.key == "K")
check("periodic[offline] -> timer remains scheduled", k.periodic_timer_running)

# --- Case L: in-flight validation and inactive lifecycle cannot start duplicate periodic requests ---
verdict("valid")
l = Auth(key="K", hwid="H"); l.login("K"); l.start_periodic_timer()
l.revalidating = True
before = l.revalidations
check("periodic[in-flight] -> duplicate request blocked", not l.periodic_tick() and l.revalidations == before)
l.revalidating = False
l.set_active(False)
check("periodic[background] -> timer stops", not l.periodic_timer_running)
check("periodic[background] -> no request", not l.periodic_tick() and l.revalidations == before)

# --- Case M: manual logout stops future periodic checks ---
m = Auth(key="K", hwid="H"); m.login("K"); m.start_periodic_timer(); m.clear_session()
check("periodic[logout] -> timer stops", not m.periodic_timer_running)
check("periodic[logout] -> no request", not m.periodic_tick())

print()
print("RESULT:", "ALL PASS" if not fails else "%d FAILURES" % len(fails))
sys.exit(1 if fails else 0)
