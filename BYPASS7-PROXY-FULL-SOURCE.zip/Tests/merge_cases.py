import sys

def old_load(bundle, disk):
    by_id = {}
    for it in bundle:
        by_id[it["id"]] = it
    for it in disk:
        by_id[it["id"]] = it          # OLD: disco sobrescreve
    return sorted(by_id.values(), key=lambda x: (not x["official"], x["id"]))

def new_load(bundle, disk):
    by_id = {}
    for it in bundle:
        by_id[it["id"]] = it          # oficiais primeiro
        log("loaded bundled official %s from bundle-url" % it["id"])
    for it in disk:
        if it["id"] in by_id:
            if by_id[it["id"]]["official"]:
                log("skipped disk package %s — official %s wins" % (it["url"], it["id"]))
            continue
        by_id[it["id"]] = it
    return sorted(by_id.values(), key=lambda x: (not x["official"], x["id"]))

def mk(iid, official, url):
    return {"id": iid, "official": official, "url": url, "path": "Bundle.main" if official else url}

def sig(items):
    return [(i["id"], i["official"], "bundle" if i["official"] else i["url"]) for i in items]

log_msgs = []
def log(m):
    log_msgs.append(m)

A, B, C = "A", "B", "C"
bA  = mk(A, True, "Payload/3105.app/144FPS.@Bypass7proxy.3105")
bB  = mk(B, True, "Payload/3105.app/PESCOCO_MAX.3105")
dA  = mk(A, False, "disk/A.3105")
dB  = mk(B, False, "disk/B.3105")
dC  = mk(C, False, "disk/C.3105")

cases = [
    ("1. bundle:A | disk:none   -> A oficial",                [bA],          [],
     [(A, True, "bundle")]),
    ("2. bundle:A | disk:A      -> so A oficial (bundle)",    [bA],          [dA],
     [(A, True, "bundle")]),
    ("3. bundle:A | disk:B      -> A oficial + B user",       [bA],          [dB],
     [(A, True, "bundle"), (B, False, "disk/B.3105")]),
    ("4. bundle:A,B | disk:A,B,C-> A,B oficiais + C user",    [bA, bB],      [dA, dB, dC],
     [(A, True, "bundle"), (B, True, "bundle"), (C, False, "disk/C.3105")]),
    ("5. oficias mantem isOfficialPreset=true e path=bundle", [bA, bB],      [dA, dB, dC],
     [(A, True, "bundle"), (B, True, "bundle"), (C, False, "disk/C.3105")]),
]
fails = 0
for name, bundle, disk, expected in cases:
    got = sig(new_load(bundle, disk))
    ok = got == expected
    if not ok:
        fails += 1
    print("%s => %s %s" % ("[PASS]" if ok else "[FAIL]", name, got))
print()
old_ok = old_load([bA], [dA])  # caso 2 no algoritmo antigo
print("[%s] OLD logic case2 (disk must NOT replace official): got %s (bug reproduzido)" %
      ("FAIL" if sig(old_ok)[0][1] == False else "PASS", sig(old_ok)))
if sig(old_ok)[0][1] == False:
    print("    -> confirma o bug do diagnostico: disco sobrescreveu o oficial")
print()
print("logs de load (partial):")
for m in log_msgs[:6]:
    print("   ", m)
print()
print("RESULT: %s" % ("ALL CASES PASS" if fails == 0 else "%d FAILURES" % fails))
sys.exit(1 if fails else 0)