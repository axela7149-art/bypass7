import hashlib
import plistlib
import re
from pathlib import Path

from cryptography.hazmat.primitives.ciphers.aead import AESGCM

ROOT = Path(__file__).resolve().parent.parent
OFFICIAL_DIR = ROOT / "ThreeOneOSFive" / "Resources" / "OfficialPatches"
STORE = ROOT / "ThreeOneOSFive" / "helpers" / "PatchProjectStore.swift"
MAGIC = b"3105PATCH\0"
FPS144_ID = "0856F902-5DD8-4721-A5E5-771F1D3EFA0B"

# Read the secret from the single source of truth in the app code so the
# password literal stays in exactly one place in this working tree.
src = STORE.read_text(encoding="utf-8")
pw_match = re.search(r"autoUnlockableOfficialPassword = \"([^\"]*)\"", src)
id_match = re.search(r"autoUnlockableOfficialPackageID = UUID\(\s*uuidString: \"([^\"]*)\"", src)
pesc_pw_match = re.search(r"autoUnlockablePescocoPassword = \"([^\"]*)\"", src)
pesc_id_match = re.search(r"autoUnlockablePescocoPackageID = UUID\(\s*uuidString: \"([^\"]*)\"", src)
saci_pw_match = re.search(r"autoUnlockableSaciPassword = \"([^\"]*)\"", src)
saci_id_match = re.search(r"autoUnlockableSaciPackageID = UUID\(\s*uuidString: \"([^\"]*)\"", src)
PASSWORD = pw_match.group(1)
AUTO_ID = id_match.group(1).upper()
PESC_PASSWORD = pesc_pw_match.group(1)
PESCOCO_ID = pesc_id_match.group(1).upper()
SACI_PASSWORD = saci_pw_match.group(1)
SACI_ID = saci_id_match.group(1).upper()
assert AUTO_ID == FPS144_ID, f"source auto-unlock packageID mismatch: {AUTO_ID}"


def parse_package(path: Path):
    data = path.read_bytes()
    assert data.startswith(MAGIC), f"{path.name}: bad magic"
    env = plistlib.loads(data[len(MAGIC):])
    return data, env


def auto_unlockable(is_official: bool, package_id: str):
    return is_official and package_id in (AUTO_ID, PESCOCO_ID, SACI_ID)


def decode_with_password(path: Path, password: str = PASSWORD):
    data, env = parse_package(path)
    pid = env["packageID"].upper()
    wrap = hashlib.pbkdf2_hmac(
        "sha256", password.encode("utf-8"), bytes(env["kdfSalt"]), env["kdfIterations"], 32
    )
    key_aad = ("3105PATCH/v{}/key/{}".format(env.get("keyAADVersion") or env["schemaVersion"], pid)).encode()
    ck = AESGCM(wrap).decrypt(bytes(env["wrappedContentKey"])[:12], bytes(env["wrappedContentKey"])[12:], key_aad)
    assert hashlib.sha256(ck).hexdigest().upper() == env["keyFingerprint"].hex().upper(), "fingerprint mismatch"
    pld_aad = ("3105PATCH/v{}/payload/{}".format(env["schemaVersion"], pid)).encode()
    ep = bytes(env["encryptedPayload"])
    plain = AESGCM(ck).decrypt(ep[:12], ep[12:], pld_aad)
    project = plistlib.loads(plain)["project"]
    return pid, env["isPasswordProtected"], project


passed = failed = 0


def check(name, cond):
    global passed, failed
    if cond:
        passed += 1
    else:
        failed += 1
        print(f"FAIL: {name}")


# 1. Official 144 FPS (embedded): locked on clean install, auto-unlockable, decode works.
fps = next(OFFICIAL_DIR.glob("144FPS*"))
pid, protected, project = decode_with_password(fps)
check("144FPS is password protected", protected)
check("144FPS packageID matches", pid == FPS144_ID)
check("144FPS auto-unlockable (was locked)", auto_unlockable(True, pid))
check("144FPS decodes project name", project["name"] == "144fps @bypass7proxy")
check("144FPS has rules to apply", len(project["rules"]) >= 1)
# Clean-install simulation: with no stored key the item is locked (project nil);
# after auto-unlock decode yields a project -> unlocked -> apply proceeds.
check("144FPS after auto-unlock is unlocked (project non-nil)", project is not None)

# 2. Official HS PESCOÇO (embedded): protected, auto-unlockable, decodes with its own key.
pesc = next(OFFICIAL_DIR.glob("*PESCO*3105"))
ppid, pp_, pesc_project = None, None, None
if pesc:
    ppid, pp_, pesc_project = decode_with_password(pesc, PESC_PASSWORD)
check("PESCOÇO is password protected", pp_ is True)
check("PESCOÇO packageID matches source", ppid == PESCOCO_ID)
check("PESCOÇO auto-unlockable (was locked)", auto_unlockable(True, ppid))
check("PESCOÇO decodes with its internal password (cross-DIRECT project OK)", pesc_project is not None)
if pesc_project is not None:
    check("PESCOÇO decodes project name", pesc_project["name"] == "BYPASS7PROXY  x  HS PESCOÇO MAX")
    check("PESCOÇO has rules to apply", len(pesc_project["rules"]) >= 1)
check("PESCOÇO after auto-unlock is unlocked (project non-nil)", pesc_project is not None)
check("PESCOÇO has distinct packageID", ppid != FPS144_ID)

# 2b. 144 FPS regression: still auto-unlockable and decodes with its own password.
pid, protected, project = decode_with_password(fps, PASSWORD)
check("144FPS still auto-unlockable", auto_unlockable(True, pid))
check("144FPS still decodes", project is not None)

# 2c. Official HS SACI (embedded): protected, auto-unlockable, decodes with its own key.
saci = next(OFFICIAL_DIR.glob("*SACI*3105"))
spid, sp_, saci_project = None, None, None
if saci:
    spid, sp_, saci_project = decode_with_password(saci, SACI_PASSWORD)
check("SACI is password protected", sp_ is True)
check("SACI packageID matches source", spid == SACI_ID)
check("SACI auto-unlockable (was locked)", auto_unlockable(True, spid))
check("SACI decodes with its internal password (cross-DIRECT project OK)", saci_project is not None)
if saci_project is not None:
    check("SACI decodes project name", saci_project["name"] == "@BYPASS7PROXY - HS SACI")
    check("SACI has rules to apply", len(saci_project["rules"]) >= 1)
check("SACI after auto-unlock is unlocked (project non-nil)", saci_project is not None)
check("SACI has distinct packageID", spid != FPS144_ID and spid != PESCOCO_ID)

# 2d. 144 FPS & PESCOÇO regression: still auto-unlockable and decode.
pid, protected, project = decode_with_password(fps, PASSWORD)
check("144FPS still auto-unlockable", auto_unlockable(True, pid))
check("144FPS still decodes", project is not None)
ppid, pp_, pesc_project = decode_with_password(next(OFFICIAL_DIR.glob("*PESCO*3105")), PESC_PASSWORD)
check("PESCOÇO still auto-unlockable", auto_unlockable(True, ppid))
check("PESCOÇO still decodes", pesc_project is not None)

# 3. User-imported protected preset with the SAME packageID: NOT auto-unlockable.
check("user duplicate of 144FPS still prompts", not auto_unlockable(False, FPS144_ID))
check("user duplicate of PESCOÇO still prompts", not auto_unlockable(False, PESCOCO_ID))
check("user duplicate of SACI still prompts", not auto_unlockable(False, SACI_ID))

# 4. User-imported generic protected preset: NOT auto-unlockable.
check("generic user preset still prompts", not auto_unlockable(False, "11111111-2222-3333-4444-555555555555"))

# 5. User preset remains editable (isOfficialPreset false preserves normal editing).
check("user presets keep normal editing path", not auto_unlockable(False, "AAAAAAAA-BBBB-CCCC-DDDD-EEEEEEEEEEEE"))


# 6. View auto-apply decision AFTER the unlock completion callback (mirror of the
#    Swift closure in InjectFeaturesView.apply). Deterministic: the completion is
#    emitted exactly once per request, tied to the item's packageID (NOT item.id
#    churn); the view applies once only when success + still unlocked.
def view_apply(package_id, success, pending, unlocked_ids):
    if package_id != pending:
        return "clear-no-apply"
    if not success:
        return "clear-no-apply"
    if package_id in unlocked_ids:
        return "apply"
    return "clear-no-apply"


# 6a. 144 FPS auto-apply path.
pending = pid
check("auto-apply after successful unlock (no second tap)", view_apply(pid, True, pending, {pid}) == "apply")
check("unlock FAILURE never applies", view_apply(pid, False, pending, {pid}) != "apply")
check("stale/different request clears flag, no apply", view_apply("99999999-0000-1111-2222-333333333333", True, pending, {"99999999-0000-1111-2222-333333333333"}) != "apply")
check("apply fires exactly once per completion (single request, single apply)", [view_apply(pid, True, pending, {pid}) == "apply"] == [True])
check("already-unlocked 144FPS goes straight to apply (no unlock request)", view_apply(pid, True, pid, {pid}) == "apply")
check("144FPS only enters auto path when locked (official + fps144 + locked)", auto_unlockable(True, pid) and view_apply(pid, True, pid, {pid}) == "apply")

# 6b. HS PESCOÇO auto-apply path (same deterministic completion).
check("PESCOÇO auto-apply after unlock (no second tap)", view_apply(ppid, True, ppid, {ppid}) == "apply")
check("PESCOÇO unlock FAILURE never applies", view_apply(ppid, False, ppid, {ppid}) != "apply")
check("PESCOÇO auto path only when official + locked", auto_unlockable(True, ppid) and view_apply(ppid, True, ppid, {ppid}) == "apply")
check("PESCOÇO user duplicate NOT on auto path", not auto_unlockable(False, ppid))

# 6c. HS SACI auto-apply path (same deterministic completion).
check("SACI auto-apply after unlock (no second tap)", view_apply(spid, True, spid, {spid}) == "apply")
check("SACI unlock FAILURE never applies", view_apply(spid, False, spid, {spid}) != "apply")
check("SACI auto path only when official + locked", auto_unlockable(True, spid) and view_apply(spid, True, spid, {spid}) == "apply")
check("SACI user duplicate NOT on auto path", not auto_unlockable(False, spid))

print(f"\nPASS={passed} FAIL={failed}")
raise SystemExit(1 if failed else 0)